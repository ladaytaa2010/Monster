# TASK: Create a Browser-Based Match-3 Cryptid Makeover Game

## Objective: Build a carbon copy of Project Makeover as a web game, but with cryptid monsters that need curse-breaking instead of human makeovers.

## STEPs:
[ ] STEP 1: Research Project Makeover game mechanics, graphics style, power-ups, and level progression to understand the core gameplay loop -> Research STEP
[ ] STEP 2: Build the full-stack web game with match-3 mechanics, cryptid storyline, 15 levels, power-ups, and progression system -> Full-Stack Web STEP

## Key Requirements:
- **Core Gameplay**: Match-3 puzzle mechanics identical to Project Makeover
- **Graphics**: Similar visual style and design aesthetics
- **Power-ups**: Same types of power-ups and special tiles
- **Storyline**: Evil witch Morganna is cursing people in Washington D.C., turning them into vampires, werewolves, zombies, and other monsters
- **Monsters**: Vampires, werewolves, zombies, and other classic cryptids
- **Setting**: Washington, D.C. under siege by Morganna's curse
- **Progression**: 15 levels required to break each monster's curse and restore them to human form
- **Monetization**: Coin collection system for curse-breaking
- **Platform**: Browser-playable web application

## Success Criteria:
- [ ] Functional match-3 game with drag-and-drop or click mechanics
- [ ] At least 15 levels with increasing difficulty
- [ ] Power-up system (bombs, line clears, etc.)
- [ ] Cryptid monster storyline with curse-breaking mechanics
- [ ] Coin collection and spending system
- [ ] Visual progression showing monster transformation
- [ ] Responsive design for desktop and mobile browsers

## Deliverable: A publicly accessible URL for the cryptid makeover match-3 game.