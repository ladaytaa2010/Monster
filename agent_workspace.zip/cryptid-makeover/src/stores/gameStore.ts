import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Monster {
  id: string;
  name: string;
  title: string;
  description: string;
  background: string;
  beforeImage: string;
  afterImage: string;
  location: string;
  tasks: Task[];
}

export interface Task {
  id: string;
  name: string;
  description: string;
  cost: number;
  completed: boolean;
}

export interface Level {
  id: number;
  monster: string;
  objective: string;
  moves: number;
  targetTiles: { [key: string]: number };
  obstacles: string[];
  boardSize: { width: number; height: number };
  reward: number;
  completed?: boolean;
  stars?: number;
}

export interface GameState {
  // Player Progress
  coins: number;
  lives: number;
  currentMonster: string;
  currentLevel: number;
  
  // Game Data
  monsters: { [key: string]: Monster };
  levels: { [key: string]: Level[] };
  
  // Current Game Session
  isPlaying: boolean;
  isPaused: boolean;
  currentLevelData: Level | null;
  
  // UI State
  showModal: boolean;
  modalType: 'story' | 'victory' | 'defeat' | 'task' | 'settings' | null;
  modalData: any;
  
  // Sound settings
  soundEnabled: boolean;
  musicEnabled: boolean;
  
  // Actions
  initializeGame: () => Promise<void>;
  setCoins: (coins: number) => void;
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => boolean;
  setLives: (lives: number) => void;
  useLive: () => boolean;
  setCurrentMonster: (monsterId: string) => void;
  setCurrentLevel: (levelId: number) => void;
  completeLevel: (levelId: number, stars: number) => void;
  completeTask: (monsterId: string, taskId: string) => void;
  startLevel: (level: Level) => void;
  endLevel: (success: boolean, stars?: number) => void;
  showModalDialog: (type: 'story' | 'victory' | 'defeat' | 'task' | 'settings', data?: any) => void;
  hideModal: () => void;
  toggleSound: () => void;
  toggleMusic: () => void;
  resetGame: () => void;
}

const initialState = {
  coins: 1000,
  lives: 5,
  currentMonster: 'vampire',
  currentLevel: 1,
  monsters: {},
  levels: {},
  isPlaying: false,
  isPaused: false,
  currentLevelData: null,
  showModal: false,
  modalType: null,
  modalData: null,
  soundEnabled: true,
  musicEnabled: true,
};

export const useGameStore = create<GameState>()(persist(
  (set, get) => ({
    ...initialState,
    
    initializeGame: async () => {
      try {
        // Load monsters data
        const monstersResponse = await fetch('/data/monsters.json');
        const monstersData = await monstersResponse.json();
        
        // Load levels data
        const levelsResponse = await fetch('/data/levels.json');
        const levelsData = await levelsResponse.json();
        
        set({ 
          monsters: monstersData, 
          levels: levelsData 
        });
      } catch (error) {
        console.error('Failed to initialize game data:', error);
      }
    },
    
    setCoins: (coins: number) => set({ coins }),
    
    addCoins: (amount: number) => set((state) => ({ 
      coins: state.coins + amount 
    })),
    
    spendCoins: (amount: number) => {
      const state = get();
      if (state.coins >= amount) {
        set({ coins: state.coins - amount });
        return true;
      }
      return false;
    },
    
    setLives: (lives: number) => set({ lives }),
    
    useLive: () => {
      const state = get();
      if (state.lives > 0) {
        set({ lives: state.lives - 1 });
        return true;
      }
      return false;
    },
    
    setCurrentMonster: (monsterId: string) => set({ 
      currentMonster: monsterId,
      currentLevel: 1 // Reset to first level of new monster
    }),
    
    setCurrentLevel: (levelId: number) => set({ currentLevel: levelId }),
    
    completeLevel: (levelId: number, stars: number) => {
      const state = get();
      const monsterLevels = state.levels[state.currentMonster];
      if (monsterLevels) {
        const level = monsterLevels.find(l => l.id === levelId);
        if (level) {
          level.completed = true;
          level.stars = Math.max(level.stars || 0, stars);
          
          // Add reward coins
          const newCoins = state.coins + level.reward;
          set({ 
            coins: newCoins,
            levels: { ...state.levels }
          });
        }
      }
    },
    
    completeTask: (monsterId: string, taskId: string) => {
      const state = get();
      const monster = state.monsters[monsterId];
      if (monster) {
        const task = monster.tasks.find(t => t.id === taskId);
        if (task && !task.completed) {
          if (state.coins >= task.cost) {
            task.completed = true;
            set({ 
              coins: state.coins - task.cost,
              monsters: { ...state.monsters }
            });
          }
        }
      }
    },
    
    startLevel: (level: Level) => set({ 
      isPlaying: true, 
      currentLevelData: level,
      showModal: false
    }),
    
    endLevel: (success: boolean, stars = 0) => {
      const state = get();
      if (success && state.currentLevelData) {
        get().completeLevel(state.currentLevelData.id, stars);
      }
      set({ 
        isPlaying: false, 
        currentLevelData: null 
      });
    },
    
    showModalDialog: (type, data = null) => set({ 
      showModal: true, 
      modalType: type, 
      modalData: data 
    }),
    
    hideModal: () => set({ 
      showModal: false, 
      modalType: null, 
      modalData: null 
    }),
    
    toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled })),
    
    toggleMusic: () => set((state) => ({ musicEnabled: !state.musicEnabled })),
    
    resetGame: () => set(initialState),
  }),
  {
    name: 'cryptid-makeover-game',
    version: 1,
  }
));