import React, { useState, useEffect } from 'react';
import { MainMenu } from './components/screens/MainMenu';
import { MakeoverHub } from './components/screens/MakeoverHub';
import { GameScreen } from './components/screens/GameScreen';
import { StoryModal } from './components/modals/StoryModal';
import { VictoryModal } from './components/modals/VictoryModal';
import { DefeatModal } from './components/modals/DefeatModal';
import { useGameStore } from './stores/gameStore';

type Screen = 'menu' | 'hub' | 'game';
type GameResult = { success: boolean; stars: number; level: number } | null;

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('menu');
  const [showStoryModal, setShowStoryModal] = useState(false);
  const [gameResult, setGameResult] = useState<GameResult>(null);
  
  const {
    startLevel,
    endLevel,
    currentLevelData,
    setCurrentLevel,
    currentLevel,
    currentMonster,
    levels,
    useLive,
    initializeGame
  } = useGameStore();

  useEffect(() => {
    initializeGame();
  }, [initializeGame]);

  const handleStartGame = () => {
    setCurrentScreen('hub');
  };

  const handleShowStory = () => {
    setShowStoryModal(true);
  };

  const handleShowSettings = () => {
    // TODO: Implement settings modal
    console.log('Settings clicked');
  };

  const handleBackToMenu = () => {
    setCurrentScreen('menu');
    endLevel(false);
  };

  const handleStartLevel = () => {
    const monsterLevels = levels[currentMonster];
    if (monsterLevels) {
      const levelData = monsterLevels.find(l => l.id === currentLevel);
      if (levelData) {
        startLevel(levelData);
        setCurrentScreen('game');
      }
    }
  };

  const handleBackToHub = () => {
    setCurrentScreen('hub');
    endLevel(false);
    setGameResult(null);
  };

  const handleLevelComplete = (success: boolean, stars: number) => {
    endLevel(success, stars);
    setGameResult({ success, stars, level: currentLevel });
  };

  const handleNextLevel = () => {
    const monsterLevels = levels[currentMonster];
    if (monsterLevels) {
      const nextLevelId = currentLevel + 1;
      const nextLevel = monsterLevels.find(l => l.id === nextLevelId);
      
      if (nextLevel) {
        setCurrentLevel(nextLevelId);
        setGameResult(null);
        handleStartLevel();
      } else {
        // No more levels for this monster
        handleBackToHub();
      }
    }
  };

  const handleRetryLevel = () => {
    if (useLive()) {
      setGameResult(null);
      handleStartLevel();
    } else {
      // No lives left
      handleBackToHub();
    }
  };

  const handleSelectTask = (taskId: string) => {
    // TODO: Show task completion animation
    console.log('Task completed:', taskId);
  };

  const handleCloseStoryModal = () => {
    setShowStoryModal(false);
  };

  const handleCloseResultModal = () => {
    setGameResult(null);
  };

  // Check if this is the last level for the current monster
  const isLastLevel = () => {
    const monsterLevels = levels[currentMonster];
    if (!monsterLevels || !gameResult) return false;
    
    const lastLevel = monsterLevels[monsterLevels.length - 1];
    return gameResult.level === lastLevel.id;
  };

  return (
    <div className="min-h-screen bg-[#2c2a4a]">
      {/* Main Screens */}
      {currentScreen === 'menu' && (
        <MainMenu
          onStartGame={handleStartGame}
          onShowStory={handleShowStory}
          onShowSettings={handleShowSettings}
        />
      )}
      
      {currentScreen === 'hub' && (
        <MakeoverHub
          onBackToMenu={handleBackToMenu}
          onStartLevel={handleStartLevel}
          onSelectTask={handleSelectTask}
        />
      )}
      
      {currentScreen === 'game' && (
        <GameScreen
          onBackToHub={handleBackToHub}
          onLevelComplete={handleLevelComplete}
        />
      )}

      {/* Modals */}
      <StoryModal
        isOpen={showStoryModal}
        onClose={handleCloseStoryModal}
      />
      
      {gameResult?.success && (
        <VictoryModal
          isOpen={true}
          onClose={handleCloseResultModal}
          onNextLevel={handleNextLevel}
          onBackToHub={handleBackToHub}
          stars={gameResult.stars}
          coinsEarned={currentLevelData?.reward || 0}
          level={gameResult.level}
          isLastLevel={isLastLevel()}
        />
      )}
      
      {gameResult && !gameResult.success && (
        <DefeatModal
          isOpen={true}
          onClose={handleCloseResultModal}
          onRetry={handleRetryLevel}
          onBackToHub={handleBackToHub}
          level={gameResult.level}
        />
      )}
    </div>
  );
}

export default App;