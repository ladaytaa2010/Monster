import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  className,
  children,
  ...props
}) => {
  const baseClasses = 'font-bold uppercase tracking-wide rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2';
  
  const variantClasses = {
    primary: 'bg-gradient-to-b from-[#ff47da] to-[#ff79e6] text-white shadow-lg shadow-[#2c2a4a]/50 hover:shadow-xl hover:shadow-[#ff47da]/30 focus:ring-[#ff47da]',
    secondary: 'bg-gradient-to-b from-[#4f518c] to-[#6366b1] text-white shadow-lg shadow-[#2c2a4a]/50 hover:shadow-xl focus:ring-[#4f518c]',
    danger: 'bg-gradient-to-b from-[#e63946] to-[#dc2626] text-white shadow-lg shadow-[#2c2a4a]/50 hover:shadow-xl focus:ring-[#e63946]'
  };
  
  const sizeClasses = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg'
  };

  const { 
    onDrag, 
    onDragEnd, 
    onDragStart, 
    onAnimationStart,
    onAnimationEnd,
    onAnimationIteration,
    ...buttonProps 
  } = props;
  
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        baseClasses,
        variantClasses[variant],
        sizeClasses[size],
        className
      )}
      {...buttonProps}
    >
      {children}
    </motion.button>
  );
};