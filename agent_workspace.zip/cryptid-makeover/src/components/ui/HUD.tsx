import React from 'react';
import { motion } from 'framer-motion';
import { Coins, Heart, Target, Zap } from 'lucide-react';
import { useGameStore } from '../../stores/gameStore';

interface HUDProps {
  movesLeft?: number;
  score?: number;
  targetProgress?: { [key: string]: number };
  level?: any;
}

export const HUD: React.FC<HUDProps> = ({
  movesLeft = 0,
  score = 0,
  targetProgress = {},
  level
}) => {
  const { coins, lives, currentLevelData } = useGameStore();

  return (
    <div className="bg-gradient-to-r from-[#2c2a4a] to-[#4f518c] text-white p-4 rounded-lg shadow-lg">
      <div className="flex justify-between items-center">
        {/* Left side - Resources */}
        <div className="flex items-center space-x-6">
          {/* Coins */}
          <motion.div 
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.05 }}
          >
            <Coins className="text-[#ffd700]" size={24} />
            <span className="font-bold text-lg">{coins.toLocaleString()}</span>
          </motion.div>
          
          {/* Lives */}
          <motion.div 
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.05 }}
          >
            <Heart className="text-[#ff47da]" size={24} />
            <span className="font-bold text-lg">{lives}</span>
          </motion.div>
        </div>

        {/* Center - Level Info */}
        {currentLevelData && (
          <div className="text-center">
            <h3 className="font-['Luckiest_Guy'] text-xl uppercase">
              Level {currentLevelData.id}
            </h3>
            <p className="text-sm opacity-90">{currentLevelData.objective}</p>
          </div>
        )}

        {/* Right side - Game State */}
        <div className="flex items-center space-x-6">
          {/* Moves Left */}
          <motion.div 
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.05 }}
          >
            <Zap className="text-[#00f5d4]" size={24} />
            <span className="font-bold text-lg">{movesLeft}</span>
          </motion.div>
          
          {/* Score */}
          <motion.div 
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.05 }}
          >
            <Target className="text-[#ffd700]" size={24} />
            <span className="font-bold text-lg">{score.toLocaleString()}</span>
          </motion.div>
        </div>
      </div>

      {/* Target Progress */}
      {level && Object.keys(level.targetTiles || {}).length > 0 && (
        <div className="mt-4 p-3 bg-black/20 rounded-lg">
          <h4 className="text-sm font-semibold mb-2 uppercase tracking-wide opacity-90">Objectives</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {Object.entries(level.targetTiles).map(([tileType, required]) => {
              const collected = targetProgress[tileType] || 0;
              const progress = Math.min(100, (collected / (required as number)) * 100);
              
              return (
                <div key={tileType} className="flex items-center space-x-2">
                  <div className="w-6 h-6 rounded bg-gradient-to-br from-[#ff47da] to-[#00f5d4] flex items-center justify-center text-xs font-bold">
                    {tileType.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 text-xs">
                    <div className="flex justify-between mb-1">
                      <span className="capitalize">{tileType}</span>
                      <span>{collected}/{required as number}</span>
                    </div>
                    <div className="w-full bg-[#4f518c] rounded-full h-2">
                      <motion.div
                        className="bg-gradient-to-r from-[#00f5d4] to-[#ff47da] h-2 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};