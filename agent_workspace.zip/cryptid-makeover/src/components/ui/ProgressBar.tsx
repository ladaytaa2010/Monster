import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface ProgressBarProps {
  progress: number; // 0-100
  className?: string;
  showText?: boolean;
  text?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  className,
  showText = true,
  text
}) => {
  const clampedProgress = Math.max(0, Math.min(100, progress));
  
  return (
    <div className={cn('w-full', className)}>
      <div className="bg-[#4f518c] rounded-full h-4 overflow-hidden shadow-inner">
        <motion.div
          className="h-full bg-gradient-to-r from-[#00f5d4] to-[#ff47da] relative"
          initial={{ width: 0 }}
          animate={{ width: `${clampedProgress}%` }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        >
          {/* Shine effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
        </motion.div>
      </div>
      
      {showText && (
        <div className="text-center mt-2 text-sm font-semibold text-[#333333]">
          {text || `${Math.round(clampedProgress)}%`}
        </div>
      )}
    </div>
  );
};