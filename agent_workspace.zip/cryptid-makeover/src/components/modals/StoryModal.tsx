import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';

interface StoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface StoryData {
  title: string;
  intro: {
    title: string;
    text: string;
  };
  villain: {
    name: string;
    title: string;
    description: string;
    motivation: string;
    weakness: string;
  };
  setting: {
    location: string;
    atmosphere: string;
    landmarks: string[];
  };
  player_role: {
    title: string;
    description: string;
    powers: string[];
  };
}

export const StoryModal: React.FC<StoryModalProps> = ({ isOpen, onClose }) => {
  const [storyData, setStoryData] = useState<StoryData | null>(null);
  const [currentPage, setCurrentPage] = useState(0);

  useEffect(() => {
    if (isOpen) {
      fetch('/data/story.json')
        .then(response => response.json())
        .then(data => setStoryData(data))
        .catch(error => console.error('Failed to load story data:', error));
    }
  }, [isOpen]);

  if (!storyData) {
    return (
      <Modal isOpen={isOpen} onClose={onClose} title="Loading...">
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-4 border-[#ff47da] border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading story...</p>
        </div>
      </Modal>
    );
  }

  const pages = [
    {
      title: storyData.intro.title,
      content: (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <img 
              src="/images/washington-dc.jpg" 
              alt="Washington DC" 
              className="w-full h-32 object-cover rounded-lg mb-4"
            />
          </div>
          <p className="text-[#333333] leading-relaxed">
            {storyData.intro.text}
          </p>
        </div>
      )
    },
    {
      title: "The Villain",
      content: (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <img 
              src="/images/morganna-witch.jpeg" 
              alt="Morganna the Witch" 
              className="w-32 h-32 object-cover rounded-full mx-auto mb-4 border-4 border-[#e63946]"
            />
            <h3 className="font-['Luckiest_Guy'] text-xl text-[#e63946] uppercase">
              {storyData.villain.name}
            </h3>
            <p className="text-[#666666] italic">{storyData.villain.title}</p>
          </div>
          
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Background:</h4>
              <p className="text-[#666666] text-sm">{storyData.villain.description}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Motivation:</h4>
              <p className="text-[#666666] text-sm">{storyData.villain.motivation}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Weakness:</h4>
              <p className="text-[#666666] text-sm">{storyData.villain.weakness}</p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "The Setting",
      content: (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <img 
              src="/images/washington-dc.jpg" 
              alt="Washington DC" 
              className="w-full h-32 object-cover rounded-lg mb-4"
            />
            <h3 className="font-['Luckiest_Guy'] text-xl text-[#4f518c] uppercase">
              {storyData.setting.location}
            </h3>
          </div>
          
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Atmosphere:</h4>
              <p className="text-[#666666] text-sm">{storyData.setting.atmosphere}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Key Locations:</h4>
              <ul className="text-[#666666] text-sm space-y-1">
                {storyData.setting.landmarks.map((landmark, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-[#ff47da] mr-2">•</span>
                    {landmark}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Your Role",
      content: (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <div className="w-24 h-24 bg-gradient-to-br from-[#ff47da] to-[#00f5d4] rounded-full flex items-center justify-center text-4xl mx-auto mb-4">
              ✨
            </div>
            <h3 className="font-['Luckiest_Guy'] text-xl text-[#ff47da] uppercase">
              {storyData.player_role.title}
            </h3>
          </div>
          
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Your Mission:</h4>
              <p className="text-[#666666] text-sm">{storyData.player_role.description}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#333333] mb-1">Your Powers:</h4>
              <ul className="text-[#666666] text-sm space-y-1">
                {storyData.player_role.powers.map((power, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-[#00f5d4] mr-2">✓</span>
                    {power}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )
    }
  ];

  const currentPageData = pages[currentPage];

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title={storyData.title}
      showCloseButton={false}
    >
      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="font-['Luckiest_Guy'] text-2xl text-[#2c2a4a] uppercase mb-6 text-center">
              {currentPageData.title}
            </h3>
            
            {currentPageData.content}
          </motion.div>
        </AnimatePresence>
        
        {/* Navigation */}
        <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
          <Button
            variant="secondary"
            onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
            disabled={currentPage === 0}
            className="flex items-center space-x-2"
          >
            <ChevronLeft size={20} />
            <span>Previous</span>
          </Button>
          
          <div className="flex space-x-2">
            {pages.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentPage(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentPage ? 'bg-[#ff47da]' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
          
          {currentPage === pages.length - 1 ? (
            <Button onClick={onClose}>
              Begin Adventure
            </Button>
          ) : (
            <Button
              onClick={() => setCurrentPage(Math.min(pages.length - 1, currentPage + 1))}
              className="flex items-center space-x-2"
            >
              <span>Next</span>
              <ChevronRight size={20} />
            </Button>
          )}
        </div>
      </div>
    </Modal>
  );
};