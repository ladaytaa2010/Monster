import React from 'react';
import { motion } from 'framer-motion';
import Confetti from 'react-confetti';
import { Star, Coins, Trophy } from 'lucide-react';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';

interface VictoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNextLevel: () => void;
  onBackToHub: () => void;
  stars: number;
  coinsEarned: number;
  level: number;
  isLastLevel?: boolean;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  isOpen,
  onClose,
  onNextLevel,
  onBackToHub,
  stars,
  coinsEarned,
  level,
  isLastLevel = false
}) => {
  return (
    <>
      {isOpen && (
        <Confetti
          width={window.innerWidth}
          height={window.innerHeight}
          numberOfPieces={100}
          recycle={false}
          colors={['#ff47da', '#00f5d4', '#ffd700', '#ff6b35']}
        />
      )}
      
      <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={isLastLevel ? "Curse Broken!" : "Level Complete!"}
        showCloseButton={false}
      >
        <div className="text-center space-y-6">
          {/* Success Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ 
              delay: 0.2, 
              type: 'spring', 
              stiffness: 200, 
              damping: 10 
            }}
          >
            {isLastLevel ? (
              <div className="text-8xl mb-4">🎆</div>
            ) : (
              <Trophy className="w-16 h-16 text-[#ffd700] mx-auto mb-4" />
            )}
          </motion.div>

          {/* Level Info */}
          <div>
            <h3 className="font-['Luckiest_Guy'] text-3xl text-[#2c2a4a] uppercase mb-2">
              {isLastLevel ? 'Monster Saved!' : `Level ${level} Complete!`}
            </h3>
            {isLastLevel && (
              <p className="text-[#666666] mb-4">
                The curse has been broken! This monster can now live freely.
              </p>
            )}
          </div>

          {/* Stars */}
          <motion.div 
            className="flex justify-center space-x-2 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {[1, 2, 3].map((starNum) => (
              <motion.div
                key={starNum}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ 
                  delay: 0.5 + (starNum * 0.1),
                  type: 'spring',
                  stiffness: 200
                }}
              >
                <Star 
                  className={`w-8 h-8 ${
                    starNum <= stars 
                      ? 'text-[#ffd700] fill-[#ffd700]' 
                      : 'text-gray-300'
                  }`}
                />
              </motion.div>
            ))}
          </motion.div>

          {/* Rewards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="bg-gradient-to-r from-[#ff47da]/10 to-[#00f5d4]/10 rounded-lg p-4"
          >
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Coins className="text-[#ffd700]" size={24} />
              <span className="font-['Luckiest_Guy'] text-2xl text-[#ffd700]">
                +{coinsEarned}
              </span>
            </div>
            <p className="text-[#666666] text-sm">Coins Earned</p>
          </motion.div>

          {/* Performance Message */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            <p className="text-[#666666] text-lg font-semibold">
              {stars === 3 && 'Perfect! Outstanding performance!'}
              {stars === 2 && 'Great job! Well done!'}
              {stars === 1 && 'Good work! You completed the level!'}
            </p>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="space-y-3 pt-4"
          >
            {!isLastLevel ? (
              <Button
                size="lg"
                onClick={onNextLevel}
                className="w-full"
              >
                Next Level
              </Button>
            ) : (
              <Button
                size="lg"
                onClick={onBackToHub}
                className="w-full"
              >
                Choose Next Monster
              </Button>
            )}
            
            <Button
              variant="secondary"
              onClick={onBackToHub}
              className="w-full"
            >
              Back to Hub
            </Button>
          </motion.div>
        </div>
      </Modal>
    </>
  );
};