import React from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Home, Heart } from 'lucide-react';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { useGameStore } from '../../stores/gameStore';

interface DefeatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRetry: () => void;
  onBackToHub: () => void;
  level: number;
}

export const DefeatModal: React.FC<DefeatModalProps> = ({
  isOpen,
  onClose,
  onRetry,
  onBackToHub,
  level
}) => {
  const { lives, coins } = useGameStore();
  const canRetry = lives > 0;
  
  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title="Level Failed"
      showCloseButton={false}
    >
      <div className="text-center space-y-6">
        {/* Defeat Icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ 
            delay: 0.2, 
            type: 'spring', 
            stiffness: 150, 
            damping: 12 
          }}
        >
          <div className="text-6xl mb-4">😢</div>
        </motion.div>

        {/* Message */}
        <div>
          <h3 className="font-['Luckiest_Guy'] text-2xl text-[#e63946] uppercase mb-2">
            Out of Moves!
          </h3>
          <p className="text-[#666666] mb-4">
            Don't give up! Every great makeover artist faces challenges.
          </p>
        </div>

        {/* Level Info */}
        <div className="bg-gradient-to-r from-[#e63946]/10 to-[#ff6b35]/10 rounded-lg p-4">
          <h4 className="font-semibold text-[#333333] mb-2">
            Level {level}
          </h4>
          <p className="text-[#666666] text-sm">
            The curse remains strong, but don't lose hope!
          </p>
        </div>

        {/* Resources */}
        <div className="flex justify-center space-x-6 text-sm">
          <div className="flex items-center space-x-2">
            <Heart className="text-[#ff47da]" size={20} />
            <span className="text-[#333333]">{lives} lives left</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[#ffd700]">💰</span>
            <span className="text-[#333333]">{coins.toLocaleString()} coins</span>
          </div>
        </div>

        {/* Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-[#00f5d4]/10 rounded-lg p-4"
        >
          <h4 className="font-semibold text-[#333333] mb-2 flex items-center justify-center">
            <span className="mr-2">💡</span>
            Pro Tip
          </h4>
          <p className="text-[#666666] text-sm">
            Look for opportunities to create power-ups by matching 4 or 5 tiles. 
            Combine power-ups for devastating effects!
          </p>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="space-y-3 pt-4"
        >
          {canRetry ? (
            <Button
              size="lg"
              onClick={onRetry}
              className="w-full flex items-center justify-center space-x-2"
            >
              <RefreshCw size={20} />
              <span>Try Again (-1 Life)</span>
            </Button>
          ) : (
            <div className="bg-[#e63946]/10 rounded-lg p-4 mb-4">
              <p className="text-[#e63946] font-semibold mb-2">
                No Lives Remaining
              </p>
              <p className="text-[#666666] text-sm">
                Lives regenerate over time, or you can return to the hub to work on other monsters.
              </p>
            </div>
          )}
          
          <Button
            variant="secondary"
            onClick={onBackToHub}
            className="w-full flex items-center justify-center space-x-2"
          >
            <Home size={20} />
            <span>Back to Hub</span>
          </Button>
        </motion.div>
      </div>
    </Modal>
  );
};