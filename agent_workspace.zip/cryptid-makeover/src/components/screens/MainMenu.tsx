import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Settings, BookOpen, Volume2, VolumeX } from 'lucide-react';
import { Button } from '../ui/Button';
import { useGameStore } from '../../stores/gameStore';

interface MainMenuProps {
  onStartGame: () => void;
  onShowStory: () => void;
  onShowSettings: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onShowStory,
  onShowSettings
}) => {
  const { 
    coins, 
    lives, 
    currentMonster, 
    monsters, 
    soundEnabled, 
    toggleSound,
    initializeGame 
  } = useGameStore();

  useEffect(() => {
    initializeGame();
  }, [initializeGame]);

  const currentMonsterData = monsters[currentMonster];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2c2a4a] via-[#4f518c] to-[#2c2a4a] flex items-center justify-center relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src="/images/washington-dc.jpg" 
          alt="Washington DC" 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-[#ff47da] rounded-full opacity-30"
            animate={{
              x: [0, 100, 0],
              y: [0, -100, 0],
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 text-center max-w-md mx-auto p-6">
        {/* Game Title */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <h1 className="font-['Luckiest_Guy'] text-6xl sm:text-7xl uppercase bg-gradient-to-r from-[#ff47da] to-[#00f5d4] bg-clip-text text-transparent mb-2">
            Cryptid
          </h1>
          <h2 className="font-['Luckiest_Guy'] text-4xl sm:text-5xl uppercase bg-gradient-to-r from-[#00f5d4] to-[#ff47da] bg-clip-text text-transparent">
            Makeover
          </h2>
          <p className="text-white/80 mt-4 text-lg font-medium">
            Break Morganna's Curses in Washington D.C.
          </p>
        </motion.div>

        {/* Player Stats */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="bg-black/30 backdrop-blur-sm rounded-2xl p-4 mb-8 border border-white/20"
        >
          <div className="flex justify-center space-x-8 text-white">
            <div className="text-center">
              <div className="font-['Luckiest_Guy'] text-2xl text-[#ffd700]">
                {coins.toLocaleString()}
              </div>
              <div className="text-sm opacity-80">Coins</div>
            </div>
            <div className="text-center">
              <div className="font-['Luckiest_Guy'] text-2xl text-[#ff47da]">
                {lives}
              </div>
              <div className="text-sm opacity-80">Lives</div>
            </div>
          </div>
          
          {currentMonsterData && (
            <div className="mt-4 pt-4 border-t border-white/20">
              <div className="text-sm text-white/80 mb-1">Current Case:</div>
              <div className="font-bold text-[#00f5d4]">{currentMonsterData.name}</div>
              <div className="text-xs text-white/60">{currentMonsterData.location}</div>
            </div>
          )}
        </motion.div>

        {/* Menu Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="space-y-4"
        >
          <Button
            size="lg"
            onClick={onStartGame}
            className="w-full flex items-center justify-center space-x-2"
          >
            <Play size={24} />
            <span>Start Game</span>
          </Button>
          
          <div className="flex space-x-4">
            <Button
              variant="secondary"
              onClick={onShowStory}
              className="flex-1 flex items-center justify-center space-x-2"
            >
              <BookOpen size={20} />
              <span>Story</span>
            </Button>
            
            <Button
              variant="secondary"
              onClick={onShowSettings}
              className="flex-1 flex items-center justify-center space-x-2"
            >
              <Settings size={20} />
              <span>Settings</span>
            </Button>
          </div>
        </motion.div>

        {/* Sound Toggle */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          onClick={toggleSound}
          className="fixed top-4 right-4 p-3 bg-black/30 backdrop-blur-sm rounded-full text-white hover:bg-black/50 transition-colors"
        >
          {soundEnabled ? <Volume2 size={24} /> : <VolumeX size={24} />}
        </motion.button>
      </div>
    </div>
  );
};