import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Pause, Home } from 'lucide-react';
import { GameCanvas } from '../game/GameCanvas';
import { HUD } from '../ui/HUD';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { useGameStore } from '../../stores/gameStore';

interface GameScreenProps {
  onBackToHub: () => void;
  onLevelComplete: (success: boolean, stars: number) => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  onBackToHub,
  onLevelComplete
}) => {
  const [gameState, setGameState] = useState({
    movesLeft: 0,
    score: 0,
    targetProgress: {},
    level: null
  });
  const [showPauseModal, setShowPauseModal] = useState(false);
  
  const { 
    addCoins, 
    currentLevelData, 
    isPlaying
  } = useGameStore();

  const handleCoinsEarned = useCallback((amount: number) => {
    addCoins(amount);
  }, [addCoins]);

  const handleMoveUsed = useCallback(() => {
    // This will be handled by the game state updates
  }, []);

  const handleGameStateChange = useCallback((state: any) => {
    setGameState(state);
  }, []);

  const handleLevelComplete = useCallback((success: boolean, stars: number) => {
    onLevelComplete(success, stars);
  }, [onLevelComplete]);

  const handlePause = () => {
    setShowPauseModal(true);
  };

  const handleResume = () => {
    setShowPauseModal(false);
  };

  if (!isPlaying || !currentLevelData) {
    return (
      <div className="min-h-screen bg-[#2c2a4a] flex items-center justify-center">
        <div className="text-white text-center">
          <h2 className="font-['Luckiest_Guy'] text-3xl mb-4">Loading Game...</h2>
          <div className="animate-spin w-8 h-8 border-4 border-[#ff47da] border-t-transparent rounded-full mx-auto"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2c2a4a] to-[#4f518c] flex flex-col">
      {/* Top HUD */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          {/* Back/Home Button */}
          <Button variant="secondary" onClick={onBackToHub}>
            <Home size={20} className="mr-2" />
            Hub
          </Button>
          
          {/* Pause Button */}
          <Button variant="secondary" onClick={handlePause}>
            <Pause size={20} className="mr-2" />
            Pause
          </Button>
        </div>
        
        <HUD 
          movesLeft={gameState.movesLeft}
          score={gameState.score}
          targetProgress={gameState.targetProgress}
          level={gameState.level || currentLevelData}
        />
      </div>

      {/* Game Canvas */}
      <div className="flex-1 px-4 pb-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="h-full"
        >
          <GameCanvas
            onLevelComplete={handleLevelComplete}
            onCoinsEarned={handleCoinsEarned}
            onMoveUsed={handleMoveUsed}
            onGameStateChange={handleGameStateChange}
          />
        </motion.div>
      </div>

      {/* Pause Modal */}
      <Modal
        isOpen={showPauseModal}
        onClose={handleResume}
        title="Game Paused"
      >
        <div className="text-center space-y-4">
          <p className="text-[#333333] mb-6">
            Take a break! Your progress is saved.
          </p>
          
          <div className="space-y-3">
            <Button
              size="lg"
              onClick={handleResume}
              className="w-full"
            >
              Resume Game
            </Button>
            
            <Button
              variant="secondary"
              onClick={onBackToHub}
              className="w-full"
            >
              Back to Hub
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};