import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Play, Check, Lock } from 'lucide-react';
import { Button } from '../ui/Button';
import { ProgressBar } from '../ui/ProgressBar';
import { useGameStore } from '../../stores/gameStore';

interface MakeoverHubProps {
  onBackToMenu: () => void;
  onStartLevel: () => void;
  onSelectTask: (taskId: string) => void;
}

export const MakeoverHub: React.FC<MakeoverHubProps> = ({
  onBackToMenu,
  onStartLevel,
  onSelectTask
}) => {
  const { 
    currentMonster, 
    monsters, 
    coins,
    levels,
    currentLevel,
    completeTask
  } = useGameStore();

  const monster = monsters[currentMonster];
  const monsterLevels = levels[currentMonster] || [];
  const currentLevelData = monsterLevels.find(l => l.id === currentLevel);
  
  if (!monster) {
    return <div>Loading...</div>;
  }

  // Calculate overall progress
  const completedTasks = monster.tasks.filter(task => task.completed).length;
  const totalTasks = monster.tasks.length;
  const overallProgress = (completedTasks / totalTasks) * 100;

  const handleTaskComplete = (taskId: string) => {
    const task = monster.tasks.find(t => t.id === taskId);
    if (task && !task.completed && coins >= task.cost) {
      completeTask(currentMonster, taskId);
      onSelectTask(taskId);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2c2a4a] via-[#4f518c] to-[#2c2a4a] relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 opacity-20">
        <img 
          src={monster.background} 
          alt={`${monster.name} background`} 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="secondary" onClick={onBackToMenu}>
            <ArrowLeft size={20} className="mr-2" />
            Back to Menu
          </Button>
          
          <div className="text-center">
            <h1 className="font-['Luckiest_Guy'] text-3xl text-white uppercase">
              {monster.name}
            </h1>
            <p className="text-[#00f5d4] font-semibold">{monster.title}</p>
            <p className="text-white/60 text-sm">{monster.location}</p>
          </div>
          
          <div className="text-right text-white">
            <div className="font-bold text-xl text-[#ffd700]">
              {coins.toLocaleString()} Coins
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Monster Status */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-white/20"
          >
            <h2 className="font-['Luckiest_Guy'] text-2xl text-white mb-4 uppercase">
              Curse Status
            </h2>
            
            <div className="mb-6">
              <ProgressBar 
                progress={overallProgress}
                text={`${completedTasks}/${totalTasks} Tasks Complete`}
                className="mb-4"
              />
            </div>

            <p className="text-white/80 mb-6 leading-relaxed">
              {monster.description}
            </p>

            {/* Character Image Placeholder */}
            <div className="bg-gradient-to-br from-[#ff47da]/20 to-[#00f5d4]/20 rounded-xl p-8 text-center">
              <div className="text-6xl mb-4">
                {currentMonster === 'vampire' ? '🧛‍♂️' : 
                 currentMonster === 'werewolf' ? '🐺' : '🧟‍♂️'}
              </div>
              <p className="text-white/60 text-sm">
                {overallProgress === 100 ? 'Curse Broken! ✨' : 'Cursed'}
              </p>
            </div>
          </motion.div>

          {/* Tasks & Game */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Current Level */}
            <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <h3 className="font-['Luckiest_Guy'] text-xl text-white mb-4 uppercase">
                Match-3 Challenge
              </h3>
              
              {currentLevelData && (
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white font-semibold">
                      Level {currentLevelData.id}
                    </span>
                    <span className="text-[#ffd700] font-semibold">
                      +{currentLevelData.reward} coins
                    </span>
                  </div>
                  <p className="text-white/80 text-sm mb-4">
                    {currentLevelData.objective}
                  </p>
                  <p className="text-white/60 text-xs">
                    Moves: {currentLevelData.moves}
                  </p>
                </div>
              )}
              
              <Button
                size="lg"
                onClick={onStartLevel}
                className="w-full flex items-center justify-center space-x-2"
              >
                <Play size={24} />
                <span>Play Level</span>
              </Button>
            </div>

            {/* Makeover Tasks */}
            <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <h3 className="font-['Luckiest_Guy'] text-xl text-white mb-4 uppercase">
                Makeover Tasks
              </h3>
              
              <div className="space-y-3">
                <AnimatePresence>
                  {monster.tasks.map((task, index) => {
                    const isAffordable = coins >= task.cost;
                    const isCompleted = task.completed;
                    const isLocked = index > 0 && !monster.tasks[index - 1].completed;
                    
                    return (
                      <motion.div
                        key={task.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className={`p-4 rounded-xl border transition-all ${
                          isCompleted 
                            ? 'bg-green-500/20 border-green-400/50' 
                            : isLocked
                            ? 'bg-gray-500/20 border-gray-400/50'
                            : isAffordable
                            ? 'bg-[#ff47da]/20 border-[#ff47da]/50 hover:bg-[#ff47da]/30 cursor-pointer'
                            : 'bg-red-500/20 border-red-400/50'
                        }`}
                        onClick={() => !isCompleted && !isLocked && isAffordable && handleTaskComplete(task.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="text-white font-semibold mb-1">
                              {task.name}
                            </h4>
                            <p className="text-white/70 text-sm mb-2">
                              {task.description}
                            </p>
                            <div className="flex items-center space-x-2">
                              <span className="text-[#ffd700] font-bold">
                                {task.cost} coins
                              </span>
                              {!isAffordable && !isCompleted && !isLocked && (
                                <span className="text-red-400 text-xs">
                                  Need {task.cost - coins} more coins
                                </span>
                              )}
                            </div>
                          </div>
                          
                          <div className="ml-4">
                            {isCompleted ? (
                              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                                <Check size={16} className="text-white" />
                              </div>
                            ) : isLocked ? (
                              <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center">
                                <Lock size={16} className="text-white" />
                              </div>
                            ) : (
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                isAffordable ? 'bg-[#ff47da]' : 'bg-red-500'
                              }`}>
                                <span className="text-white text-lg">💎</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};