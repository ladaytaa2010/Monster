import React, { useEffect, useRef } from 'react';
import { gameEngine } from '../../game/GameEngine';
import { useGameStore } from '../../stores/gameStore';

interface GameCanvasProps {
  onLevelComplete: (success: boolean, stars: number) => void;
  onCoinsEarned: (amount: number) => void;
  onMoveUsed: () => void;
  onGameStateChange: (state: any) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  onLevelComplete,
  onCoinsEarned,
  onMoveUsed,
  onGameStateChange
}) => {
  const canvasRef = useRef<HTMLDivElement>(null);
  const { currentLevelData, isPlaying } = useGameStore();

  useEffect(() => {
    if (!canvasRef.current) return;

    // Set up game callbacks
    gameEngine.setCallbacks({
      onLevelComplete,
      onCoinsEarned,
      onMoveUsed,
      onGameStateChange
    });

    return () => {
      // Cleanup is handled by the singleton game engine
    };
  }, [onLevelComplete, onCoinsEarned, onMoveUsed, onGameStateChange]);

  useEffect(() => {
    if (isPlaying && currentLevelData) {
      gameEngine.startLevel(currentLevelData);
    }
  }, [isPlaying, currentLevelData]);

  return (
    <div 
      ref={canvasRef}
      id="game-canvas" 
      className="w-full h-full min-h-[600px] bg-[#2c2a4a] rounded-lg overflow-hidden shadow-2xl"
    />
  );
};