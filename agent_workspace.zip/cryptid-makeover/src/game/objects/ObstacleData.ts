// Themed obstacle data for different monsters
export const ObstacleTypes = {
  // Vampire obstacles
  coffin: {
    color: 0x4a2c2a,
    symbol: '⚰️',
    health: 2,
    description: 'Ancient coffin - hit twice to break'
  },
  garlic: {
    color: 0xfff8dc,
    symbol: '🧄',
    health: 1,
    description: 'Vampire repellent garlic'
  },
  cross: {
    color: 0xffd700,
    symbol: '✝️',
    health: 3,
    description: 'Holy cross - very resistant'
  },
  mirror: {
    color: 0xc0c0c0,
    symbol: '🪞',
    health: 1,
    description: 'Reflective mirror'
  },
  bat: {
    color: 0x2f2f2f,
    symbol: '🦇',
    health: 1,
    description: 'Flying bat obstacle'
  },
  stake: {
    color: 0x8b4513,
    symbol: '🔨',
    health: 2,
    description: 'Wooden stake'
  },

  // Werewolf obstacles
  trap: {
    color: 0x696969,
    symbol: '🪤',
    health: 2,
    description: 'Wolf trap - dangerous'
  },
  chain: {
    color: 0x708090,
    symbol: '⛓️',
    health: 3,
    description: 'Silver chains'
  },
  wolfsbane: {
    color: 0x9370db,
    symbol: '🌿',
    health: 1,
    description: 'Wolfsbane plant'
  },
  moon: {
    color: 0xf5f5dc,
    symbol: '🌕',
    health: 1,
    description: 'Full moon phase'
  },
  web: {
    color: 0xdcdcdc,
    symbol: '🕸️',
    health: 1,
    description: 'Spider web'
  },

  // Zombie obstacles
  tombstone: {
    color: 0x708090,
    symbol: '🪦',
    health: 3,
    description: 'Ancient tombstone'
  },
  plague: {
    color: 0x32cd32,
    symbol: '☣️',
    health: 2,
    description: 'Plague vial - toxic'
  },
  decay: {
    color: 0x556b2f,
    symbol: '🤢',
    health: 2,
    description: 'Decaying matter'
  },
  bone: {
    color: 0xf5f5dc,
    symbol: '🦴',
    health: 1,
    description: 'Old bones'
  },
  skull: {
    color: 0xf8f8ff,
    symbol: '💀',
    health: 2,
    description: 'Ancient skull'
  }
};

export const MonsterObstacles = {
  vampire: ['coffin', 'garlic', 'cross', 'mirror', 'bat', 'stake'],
  werewolf: ['trap', 'chain', 'wolfsbane', 'moon', 'web'],
  zombie: ['tombstone', 'plague', 'decay', 'bone', 'skull']
};

export function getObstacleForMonster(monster: string): string {
  const obstacles = MonsterObstacles[monster as keyof typeof MonsterObstacles] || MonsterObstacles.vampire;
  return obstacles[Math.floor(Math.random() * obstacles.length)];
}