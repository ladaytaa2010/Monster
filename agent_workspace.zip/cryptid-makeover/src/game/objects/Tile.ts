import Phaser from 'phaser';

export class Tile extends Phaser.GameObjects.Container {
  private tileType: string;
  private row: number;
  private col: number;
  private isObstacleType: boolean;
  private isSelectedState: boolean = false;
  private tileSprite: Phaser.GameObjects.Image;
  private glowEffect?: Phaser.GameObjects.Graphics;

  constructor(
    scene: Phaser.Scene, 
    x: number, 
    y: number, 
    tileType: string, 
    row: number, 
    col: number,
    isObstacle: boolean = false
  ) {
    super(scene, x, y);
    
    this.tileType = tileType;
    this.row = row;
    this.col = col;
    this.isObstacleType = isObstacle;
    
    scene.add.existing(this);
    
    this.createTileVisual();
  }

  private createTileVisual() {
    // Create main tile sprite
    this.tileSprite = this.scene.add.image(0, 0, this.tileType);
    this.add(this.tileSprite);
    
    // Add obstacle overlay if needed
    if (this.isObstacleType) {
      const overlay = this.scene.add.graphics();
      overlay.fillStyle(0x000000, 0.3);
      overlay.fillRoundedRect(-32, -32, 64, 64, 8);
      this.add(overlay);
      
      // Add obstacle indicator
      const indicator = this.scene.add.graphics();
      indicator.lineStyle(3, 0xff0000, 1);
      indicator.strokeRect(-30, -30, 60, 60);
      this.add(indicator);
    }
    
    // Set interactive area
    this.setSize(64, 64);
    this.setInteractive();
  }

  public setSelected(selected: boolean) {
    this.isSelectedState = selected;
    
    if (selected) {
      // Create glow effect
      this.glowEffect = this.scene.add.graphics();
      this.glowEffect.lineStyle(4, 0xffd700, 1);
      this.glowEffect.strokeRoundedRect(-34, -34, 68, 68, 10);
      this.add(this.glowEffect);
      
      // Pulse animation
      this.scene.tweens.add({
        targets: this,
        scaleX: 1.1,
        scaleY: 1.1,
        duration: 200,
        yoyo: true,
        repeat: -1
      });
    } else {
      // Remove glow effect
      if (this.glowEffect) {
        this.glowEffect.destroy();
        this.glowEffect = undefined;
      }
      
      // Stop pulse animation
      this.scene.tweens.killTweensOf(this);
      this.setScale(1, 1);
    }
  }

  public getTileType(): string {
    return this.tileType;
  }

  public getRow(): number {
    return this.row;
  }

  public getCol(): number {
    return this.col;
  }

  public setGridPosition(row: number, col: number) {
    this.row = row;
    this.col = col;
  }

  public isObstacle(): boolean {
    return this.isObstacleType;
  }

  public isSelected(): boolean {
    return this.isSelectedState;
  }
  
  public isPowerUp(): boolean {
    return false;
  }

  public destroy() {
    if (this.glowEffect) {
      this.glowEffect.destroy();
    }
    super.destroy();
  }
}