import Phaser from 'phaser';
import { Tile } from './Tile';

export type PowerUpType = 'bomb' | 'rocket-h' | 'rocket-v' | 'rainbow';

export class PowerUp extends Tile {
  private powerUpType: PowerUpType;
  private glowTween?: Phaser.Tweens.Tween;

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    powerUpType: PowerUpType,
    row: number,
    col: number
  ) {
    super(scene, x, y, powerUpType, row, col, false);
    this.powerUpType = powerUpType;
    this.createPowerUpVisual();
  }

  private createPowerUpVisual() {
    // Remove the original tile visual
    this.removeAll(true);

    // Create power-up specific visual
    const graphics = this.scene.add.graphics();
    
    switch (this.powerUpType) {
      case 'bomb':
        // Create bomb visual
        graphics.fillStyle(0xff0000, 1);
        graphics.fillCircle(0, 0, 28);
        graphics.fillStyle(0xffffff, 1);
        graphics.fillCircle(-8, -8, 6);
        break;
        
      case 'rocket-h':
        // Create horizontal rocket
        graphics.fillStyle(0xff6b35, 1);
        graphics.fillRoundedRect(-28, -12, 56, 24, 4);
        graphics.fillStyle(0xffffff, 1);
        graphics.fillTriangle(20, 0, 28, -8, 28, 8);
        break;
        
      case 'rocket-v':
        // Create vertical rocket
        graphics.fillStyle(0xff6b35, 1);
        graphics.fillRoundedRect(-12, -28, 24, 56, 4);
        graphics.fillStyle(0xffffff, 1);
        graphics.fillTriangle(0, -20, -8, -28, 8, -28);
        break;
        
      case 'rainbow':
        // Create rainbow visual
        const colors = [0xff0000, 0xff8000, 0xffff00, 0x00ff00, 0x0080ff, 0x8000ff];
        for (let i = 0; i < colors.length; i++) {
          graphics.fillStyle(colors[i], 1);
          graphics.fillCircle(0, 0, 30 - i * 4);
        }
        break;
    }
    
    this.add(graphics);
    
    // Add glow effect
    this.createGlowEffect();
  }

  private createGlowEffect() {
    this.glowTween = this.scene.tweens.add({
      targets: this,
      scaleX: 1.1,
      scaleY: 1.1,
      duration: 800,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });
  }

  public getPowerUpType(): PowerUpType {
    return this.powerUpType;
  }

  public isPowerUp(): boolean {
    return true;
  }
  
  public getTileType(): string {
    return this.powerUpType;
  }

  public activate(board: any): { affectedTiles: Tile[], score: number } {
    const affectedTiles: Tile[] = [];
    let score = 0;

    switch (this.powerUpType) {
      case 'bomb':
        return this.activateBomb(board);
      case 'rocket-h':
        return this.activateHorizontalRocket(board);
      case 'rocket-v':
        return this.activateVerticalRocket(board);
      case 'rainbow':
        return this.activateRainbow(board);
    }

    return { affectedTiles, score };
  }

  private activateBomb(board: any): { affectedTiles: Tile[], score: number } {
    const affectedTiles: Tile[] = [];
    const centerRow = this.getRow();
    const centerCol = this.getCol();

    // Clear 3x3 area around the bomb
    for (let row = centerRow - 1; row <= centerRow + 1; row++) {
      for (let col = centerCol - 1; col <= centerCol + 1; col++) {
        if (row >= 0 && row < board.getBoardHeight() && 
            col >= 0 && col < board.getBoardWidth()) {
          const tile = board.getTileAt(row, col);
          if (tile && tile !== this && !tile.isObstacle()) {
            affectedTiles.push(tile);
          }
        }
      }
    }

    return { affectedTiles, score: Math.max(affectedTiles.length * 50, 100) };
  }

  private activateHorizontalRocket(board: any): { affectedTiles: Tile[], score: number } {
    const affectedTiles: Tile[] = [];
    const row = this.getRow();

    // Clear entire row
    for (let col = 0; col < board.getBoardWidth(); col++) {
      const tile = board.getTileAt(row, col);
      if (tile && tile !== this && !tile.isObstacle()) {
        affectedTiles.push(tile);
      }
    }

    return { affectedTiles, score: Math.max(affectedTiles.length * 25, 100) };
  }

  private activateVerticalRocket(board: any): { affectedTiles: Tile[], score: number } {
    const affectedTiles: Tile[] = [];
    const col = this.getCol();

    // Clear entire column
    for (let row = 0; row < board.getBoardHeight(); row++) {
      const tile = board.getTileAt(row, col);
      if (tile && tile !== this && !tile.isObstacle()) {
        affectedTiles.push(tile);
      }
    }

    return { affectedTiles, score: Math.max(affectedTiles.length * 25, 100) };
  }

  private activateRainbow(board: any): { affectedTiles: Tile[], score: number } {
    // This would be implemented to clear all tiles of a specific color
    // For now, return empty result
    return { affectedTiles: [], score: 100 };
  }

  public destroy() {
    if (this.glowTween) {
      this.glowTween.destroy();
    }
    super.destroy();
  }
}