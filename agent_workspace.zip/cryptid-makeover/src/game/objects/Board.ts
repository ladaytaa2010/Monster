import Phaser from 'phaser';
import { Tile } from './Tile';
import { PowerUp, PowerUpType } from './PowerUp';
import { ThemedObstacle } from './ThemedObstacle';
import { getObstacleForMonster } from './ObstacleData';
import { Level } from '../../stores/gameStore';

interface Position {
  row: number;
  col: number;
}

export class Board extends Phaser.GameObjects.Container {
  private tiles: Tile[][] = [];
  private level: Level;
  private tileSize: number = 64;
  private selectedTile: Tile | null = null;
  private isProcessing: boolean = false;
  private interactionEnabled: boolean = true;

  constructor(scene: Phaser.Scene, x: number, y: number, level: Level) {
    super(scene, x, y);
    
    try {
      this.level = level;
      this.scene.add.existing(this as any);
      
      // Calculate board position to center it
      const boardWidth = level.boardSize.width * this.tileSize;
      const boardHeight = level.boardSize.height * this.tileSize;
      this.setPosition(x - boardWidth / 2, y - boardHeight / 2);
      
      this.createBoard();
      this.setupInput();
      
      console.log('Board created successfully with', level.boardSize.width, 'x', level.boardSize.height, 'tiles');
    } catch (error) {
      console.error('Error creating board:', error);
    }
  }

  private createBoard() {
    this.tiles = [];
    
    for (let row = 0; row < this.level.boardSize.height; row++) {
      this.tiles[row] = [];
      for (let col = 0; col < this.level.boardSize.width; col++) {
        const tile = this.createTile(row, col);
        this.tiles[row][col] = tile;
        this.add(tile);
      }
    }
    
    // Add obstacles after creating base tiles
    this.addObstacles();
  }

  private createTile(row: number, col: number): Tile {
    try {
      const x = col * this.tileSize + this.tileSize / 2;
      const y = row * this.tileSize + this.tileSize / 2;
      
      // Get random tile type based on current monster
      const tileType = this.getRandomTileType();
      
      const tile = new Tile(this.scene, x, y, tileType, row, col);
      
      // Set up tile interaction
      tile.setInteractive();
      tile.on('pointerdown', () => this.onTileClicked(tile));
      
      return tile;
    } catch (error) {
      console.error('Error creating tile at', row, col, ':', error);
      // Return a basic fallback tile
      const fallbackTile = new Tile(this.scene, col * this.tileSize + this.tileSize / 2, row * this.tileSize + this.tileSize / 2, 'fang', row, col);
      fallbackTile.setInteractive();
      return fallbackTile;
    }
  }

  private getRandomTileType(): string {
    const monsterTileTypes: { [key: string]: string[] } = {
      vampire: ['fang', 'bat', 'blood'],
      werewolf: ['moon', 'paw', 'howl'],
      zombie: ['brain', 'bone', 'potion']
    };
    
    const availableTypes = monsterTileTypes[this.level.monster] || ['fang', 'bat', 'blood'];
    return availableTypes[Math.floor(Math.random() * availableTypes.length)];
  }

  private addObstacles() {
    // Add themed obstacle tiles based on level configuration
    this.level.obstacles.forEach(obstacleType => {
      const count = Math.floor(Math.random() * 5) + 3; // 3-7 obstacles
      
      for (let i = 0; i < count; i++) {
        const row = Math.floor(Math.random() * this.level.boardSize.height);
        const col = Math.floor(Math.random() * this.level.boardSize.width);
        
        if (this.tiles[row] && this.tiles[row][col]) {
          // Create themed obstacle based on monster type
          const themedObstacleType = getObstacleForMonster(this.level.monster);
          const obstacleTile = new ThemedObstacle(this.scene, 
            col * this.tileSize + this.tileSize / 2,
            row * this.tileSize + this.tileSize / 2,
            themedObstacleType, row, col
          );
          
          // Replace the existing tile
          this.remove(this.tiles[row][col]);
          this.tiles[row][col].destroy();
          this.tiles[row][col] = obstacleTile;
          this.add(obstacleTile);
          
          obstacleTile.setInteractive();
          obstacleTile.on('pointerdown', () => this.onTileClicked(obstacleTile));
        }
      }
    });
  }

  private setupInput() {
    // Enable drag and drop
    // Enable board interaction
  }

  private onTileClicked(tile: Tile) {
    if (!this.interactionEnabled || this.isProcessing) return;
    
    if (this.selectedTile === null) {
      // First tile selection
      this.selectTile(tile);
    } else if (this.selectedTile === tile) {
      // Deselect same tile
      this.deselectTile();
    } else {
      // Second tile selection - attempt swap
      this.attemptSwap(this.selectedTile, tile);
    }
  }

  private selectTile(tile: Tile) {
    this.selectedTile = tile;
    tile.setSelected(true);
  }

  private deselectTile() {
    if (this.selectedTile) {
      this.selectedTile.setSelected(false);
      this.selectedTile = null;
    }
  }

  private attemptSwap(tile1: Tile, tile2: Tile) {
    // Check if either tile is a power-up
    if (this.isPowerUp(tile1) || this.isPowerUp(tile2)) {
      this.activatePowerUp(tile1);
      this.deselectTile();
      return;
    }
    
    // Check if tiles are adjacent
    const pos1 = { row: tile1.getRow(), col: tile1.getCol() };
    const pos2 = { row: tile2.getRow(), col: tile2.getCol() };
    
    if (!this.areAdjacent(pos1, pos2)) {
      this.deselectTile();
      this.selectTile(tile2);
      return;
    }
    
    // Perform swap
    this.swapTiles(tile1, tile2);
  }

  private areAdjacent(pos1: Position, pos2: Position): boolean {
    const rowDiff = Math.abs(pos1.row - pos2.row);
    const colDiff = Math.abs(pos1.col - pos2.col);
    
    return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
  }

  private swapTiles(tile1: Tile, tile2: Tile) {
    if (tile1.isObstacle() || tile2.isObstacle()) {
      // Can't swap obstacles
      this.deselectTile();
      return;
    }
    
    this.isProcessing = true;
    this.deselectTile();
    
    // Animate swap
    const pos1 = { x: tile1.x, y: tile1.y };
    const pos2 = { x: tile2.x, y: tile2.y };
    
    this.scene.tweens.add({
      targets: tile1,
      x: pos2.x,
      y: pos2.y,
      duration: 200,
      ease: 'Power2'
    });
    
    this.scene.tweens.add({
      targets: tile2,
      x: pos1.x,
      y: pos1.y,
      duration: 200,
      ease: 'Power2',
      onComplete: () => {
        // Update positions in grid
        const row1 = tile1.getRow();
        const col1 = tile1.getCol();
        const row2 = tile2.getRow();
        const col2 = tile2.getCol();
        
        tile1.setGridPosition(row2, col2);
        tile2.setGridPosition(row1, col1);
        
        this.tiles[row1][col1] = tile2;
        this.tiles[row2][col2] = tile1;
        
        // Check for matches
        this.checkMatches();
      }
    });
    
    // Emit move used event
    this.emit('moveUsed');
  }

  private checkMatches() {
    const matchGroups: Tile[][] = [];
    const visited: boolean[][] = [];
    
    // Initialize visited array
    for (let row = 0; row < this.level.boardSize.height; row++) {
      visited[row] = new Array(this.level.boardSize.width).fill(false);
    }
    
    // Check horizontal matches
    for (let row = 0; row < this.level.boardSize.height; row++) {
      let matchCount = 1;
      let currentType = '';
      let currentGroup: Tile[] = [];
      
      for (let col = 0; col < this.level.boardSize.width; col++) {
        const tile = this.tiles[row][col];
        
        if (tile && !tile.isObstacle() && !visited[row][col]) {
          if (tile.getTileType() === currentType) {
            matchCount++;
            currentGroup.push(tile);
          } else {
            if (matchCount >= 3) {
              matchGroups.push([...currentGroup]);
              currentGroup.forEach(t => {
                visited[t.getRow()][t.getCol()] = true;
              });
            }
            currentType = tile.getTileType();
            currentGroup = [tile];
            matchCount = 1;
          }
        } else {
          if (matchCount >= 3) {
            matchGroups.push([...currentGroup]);
            currentGroup.forEach(t => {
              visited[t.getRow()][t.getCol()] = true;
            });
          }
          currentType = '';
          currentGroup = [];
          matchCount = 1;
        }
      }
      
      if (matchCount >= 3) {
        matchGroups.push([...currentGroup]);
        currentGroup.forEach(t => {
          visited[t.getRow()][t.getCol()] = true;
        });
      }
    }
    
    // Check vertical matches
    for (let col = 0; col < this.level.boardSize.width; col++) {
      let matchCount = 1;
      let currentType = '';
      let currentGroup: Tile[] = [];
      
      for (let row = 0; row < this.level.boardSize.height; row++) {
        const tile = this.tiles[row][col];
        
        if (tile && !tile.isObstacle() && !visited[row][col]) {
          if (tile.getTileType() === currentType) {
            matchCount++;
            currentGroup.push(tile);
          } else {
            if (matchCount >= 3) {
              matchGroups.push([...currentGroup]);
              currentGroup.forEach(t => {
                visited[t.getRow()][t.getCol()] = true;
              });
            }
            currentType = tile.getTileType();
            currentGroup = [tile];
            matchCount = 1;
          }
        } else {
          if (matchCount >= 3) {
            matchGroups.push([...currentGroup]);
            currentGroup.forEach(t => {
              visited[t.getRow()][t.getCol()] = true;
            });
          }
          currentType = '';
          currentGroup = [];
          matchCount = 1;
        }
      }
      
      if (matchCount >= 3) {
        matchGroups.push([...currentGroup]);
        currentGroup.forEach(t => {
          visited[t.getRow()][t.getCol()] = true;
        });
      }
    }
    
    if (matchGroups.length > 0) {
      this.processMatchGroups(matchGroups);
    } else {
      this.isProcessing = false;
    }
  }

  private processMatchGroups(matchGroups: Tile[][]) {
    let totalScore = 0;
    const matchTypes: { [key: string]: number } = {};
    const powerUpsToCreate: { position: { row: number, col: number }, type: PowerUpType }[] = [];
    
    matchGroups.forEach(group => {
      // Check for power-up creation
      const powerUpInfo = this.checkForPowerUpCreation(group);
      if (powerUpInfo) {
        powerUpsToCreate.push(powerUpInfo);
      }
      
      // Count matches by type
      group.forEach(tile => {
        const type = tile.getTileType();
        matchTypes[type] = (matchTypes[type] || 0) + 1;
      });
      
      // Calculate score
      totalScore += group.length * 100;
      
      // Animate tile removal
      group.forEach(tile => {
        this.scene.tweens.add({
          targets: tile,
          scaleX: 0,
          scaleY: 0,
          alpha: 0,
          duration: 300,
          ease: 'Power2'
        });
        
        this.createMatchParticles(tile.x, tile.y);
      });
    });
    
    // Flatten all matched tiles
    const allMatches = matchGroups.flat();
    
    // Wait for animation then process
    this.scene.time.delayedCall(300, () => {
      this.removeMatchedTiles(allMatches);
      
      // Create power-ups before dropping new tiles
      powerUpsToCreate.forEach(powerUpInfo => {
        this.createPowerUp(powerUpInfo.position.row, powerUpInfo.position.col, powerUpInfo.type);
      });
      
      this.dropTiles();
      
      // Emit match events
      Object.keys(matchTypes).forEach(type => {
        this.emit('tilesMatched', {
          type: type,
          count: matchTypes[type],
          score: totalScore * matchTypes[type] / allMatches.length
        });
      });
    });
  }
  
  private checkForPowerUpCreation(group: Tile[]): { position: { row: number, col: number }, type: PowerUpType } | null {
    if (group.length < 4) return null;
    
    // Get the center position for power-up placement
    const centerIndex = Math.floor(group.length / 2);
    const centerTile = group[centerIndex];
    const position = { row: centerTile.getRow(), col: centerTile.getCol() };
    
    // Determine power-up type based on match pattern
    if (group.length >= 5) {
      // 5+ tiles = Rainbow power-up
      return { position, type: 'rainbow' };
    } else if (group.length === 4) {
      // 4 tiles = determine if it's horizontal or vertical rocket
      const isHorizontal = group.every(tile => tile.getRow() === group[0].getRow());
      const isVertical = group.every(tile => tile.getCol() === group[0].getCol());
      
      if (isHorizontal) {
        return { position, type: 'rocket-h' };
      } else if (isVertical) {
        return { position, type: 'rocket-v' };
      } else {
        // L-shaped or T-shaped match = Bomb
        return { position, type: 'bomb' };
      }
    }
    
    return null;
  }
  
  private createPowerUp(row: number, col: number, type: PowerUpType) {
    const x = col * this.tileSize + this.tileSize / 2;
    const y = row * this.tileSize + this.tileSize / 2;
    
    const powerUp = new PowerUp(this.scene, x, y, type, row, col);
    
    if (this.tiles[row] && this.tiles[row][col]) {
      this.remove(this.tiles[row][col]);
      if (this.tiles[row][col]) {
        this.tiles[row][col].destroy();
      }
    }
    
    this.tiles[row][col] = powerUp;
    this.add(powerUp);
    
    powerUp.setInteractive();
    powerUp.on('pointerdown', () => this.onTileClicked(powerUp));
    
    // Create power-up creation effect
    this.createPowerUpEffect(x, y);
  }
  
  private createPowerUpEffect(x: number, y: number) {
    // Create explosion of sparkles
    for (let i = 0; i < 8; i++) {
      const particle = this.scene.add.image(x, y, 'sparkle');
      const angle = (i / 8) * Math.PI * 2;
      const distance = 80;
      
      this.scene.tweens.add({
        targets: particle,
        x: x + Math.cos(angle) * distance,
        y: y + Math.sin(angle) * distance,
        alpha: 0,
        scale: 2,
        duration: 600,
        ease: 'Power2',
        onComplete: () => particle.destroy()
      });
    }
    
    // Screen shake effect for power-up creation
    this.scene.cameras.main.shake(200, 0.01);
  }

  private createMatchParticles(x: number, y: number) {
    // Create star particles
    for (let i = 0; i < 5; i++) {
      const particle = this.scene.add.image(x, y, 'star');
      const angle = (i / 5) * Math.PI * 2;
      const distance = 50 + Math.random() * 50;
      
      this.scene.tweens.add({
        targets: particle,
        x: x + Math.cos(angle) * distance,
        y: y + Math.sin(angle) * distance,
        alpha: 0,
        scale: 0.5,
        duration: 500,
        ease: 'Power2',
        onComplete: () => particle.destroy()
      });
    }
  }

  private removeMatchedTiles(matches: Tile[]) {
    matches.forEach(tile => {
      const row = tile.getRow();
      const col = tile.getCol();
      
      this.remove(tile);
      tile.destroy();
      this.tiles[row][col] = null as any;
    });
  }

  private dropTiles() {
    let hasDrops = false;
    
    // Drop existing tiles
    for (let col = 0; col < this.level.boardSize.width; col++) {
      let writeRow = this.level.boardSize.height - 1;
      
      for (let row = this.level.boardSize.height - 1; row >= 0; row--) {
        if (this.tiles[row][col] && this.tiles[row][col] !== null) {
          if (writeRow !== row) {
            // Move tile down
            const tile = this.tiles[row][col];
            this.tiles[writeRow][col] = tile;
            this.tiles[row][col] = null as any;
            
            tile.setGridPosition(writeRow, col);
            
            // Animate drop
            this.scene.tweens.add({
              targets: tile,
              y: writeRow * this.tileSize + this.tileSize / 2,
              duration: 200,
              ease: 'Bounce.easeOut'
            });
            
            hasDrops = true;
          }
          writeRow--;
        }
      }
    }
    
    // Fill empty spaces with new tiles
    this.fillEmptySpaces();
    
    // Check for new matches after a delay
    this.scene.time.delayedCall(300, () => {
      this.checkMatches();
    });
  }

  private fillEmptySpaces() {
    for (let col = 0; col < this.level.boardSize.width; col++) {
      for (let row = 0; row < this.level.boardSize.height; row++) {
        if (!this.tiles[row][col] || this.tiles[row][col] === null) {
          const newTile = this.createTile(row, col);
          
          // Start above the board
          newTile.y = -this.tileSize;
          
          this.tiles[row][col] = newTile;
          this.add(newTile);
          
          // Animate drop
          this.scene.tweens.add({
            targets: newTile,
            y: row * this.tileSize + this.tileSize / 2,
            duration: 300,
            ease: 'Bounce.easeOut'
          });
        }
      }
    }
  }

  public setInteractionEnabled(enabled: boolean) {
    this.interactionEnabled = enabled;
  }
  
  private isPowerUp(tile: Tile): boolean {
    return tile instanceof PowerUp;
  }
  
  private activatePowerUp(tile: Tile) {
    if (!this.isPowerUp(tile)) return;
    
    const powerUp = tile as PowerUp;
    const result = powerUp.activate(this);
    
    // Create activation visual effect
    this.createPowerUpActivationEffect(powerUp);
    
    // Remove the power-up
    this.remove(powerUp);
    powerUp.destroy();
    this.tiles[powerUp.getRow()][powerUp.getCol()] = null as any;
    
    // Process affected tiles after a short delay
    this.scene.time.delayedCall(300, () => {
      if (result.affectedTiles.length > 0) {
        this.processMatchGroups([result.affectedTiles]);
      } else {
        this.dropTiles();
      }
    });
  }
  
  private createPowerUpActivationEffect(powerUp: PowerUp) {
    const type = powerUp.getPowerUpType();
    
    switch (type) {
      case 'bomb':
        // Bomb explosion effect
        this.scene.cameras.main.shake(300, 0.02);
        this.createExplosionEffect(powerUp.x, powerUp.y, 100);
        break;
        
      case 'rocket-h':
        // Horizontal line effect
        this.createLineEffect(powerUp.getRow(), true);
        break;
        
      case 'rocket-v':
        // Vertical line effect
        this.createLineEffect(powerUp.getCol(), false);
        break;
        
      case 'rainbow':
        // Rainbow burst effect
        this.createRainbowEffect(powerUp.x, powerUp.y);
        break;
    }
  }
  
  private createExplosionEffect(x: number, y: number, radius: number) {
    // Create expanding circle
    const explosion = this.scene.add.graphics();
    explosion.fillStyle(0xff6b35, 0.8);
    explosion.fillCircle(x, y, 10);
    
    this.scene.tweens.add({
      targets: explosion,
      scaleX: radius / 10,
      scaleY: radius / 10,
      alpha: 0,
      duration: 400,
      ease: 'Power2',
      onComplete: () => explosion.destroy()
    });
  }
  
  private createLineEffect(index: number, isHorizontal: boolean) {
    const line = this.scene.add.graphics();
    line.lineStyle(8, 0xff6b35, 1);
    
    if (isHorizontal) {
      const y = index * this.tileSize + this.tileSize / 2;
      line.moveTo(0, y);
      line.lineTo(this.level.boardSize.width * this.tileSize, y);
    } else {
      const x = index * this.tileSize + this.tileSize / 2;
      line.moveTo(x, 0);
      line.lineTo(x, this.level.boardSize.height * this.tileSize);
    }
    
    line.strokePath();
    
    this.scene.tweens.add({
      targets: line,
      alpha: 0,
      duration: 500,
      ease: 'Power2',
      onComplete: () => line.destroy()
    });
  }
  
  private createRainbowEffect(x: number, y: number) {
    const colors = [0xff0000, 0xff8000, 0xffff00, 0x00ff00, 0x0080ff, 0x8000ff];
    
    colors.forEach((color, index) => {
      const ring = this.scene.add.graphics();
      ring.lineStyle(6, color, 0.8);
      ring.strokeCircle(x, y, 20 + index * 10);
      
      this.scene.tweens.add({
        targets: ring,
        scaleX: 3,
        scaleY: 3,
        alpha: 0,
        duration: 600,
        delay: index * 50,
        ease: 'Power2',
        onComplete: () => ring.destroy()
      });
    });
  }
  
  public getBoardWidth(): number {
    return this.level.boardSize.width;
  }
  
  public getBoardHeight(): number {
    return this.level.boardSize.height;
  }
  
  public getTileAt(row: number, col: number): Tile | null {
    if (row >= 0 && row < this.level.boardSize.height && 
        col >= 0 && col < this.level.boardSize.width) {
      return this.tiles[row][col];
    }
    return null;
  }
}