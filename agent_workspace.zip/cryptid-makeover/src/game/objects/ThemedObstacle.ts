import Phaser from 'phaser';
import { Tile } from './Tile';
import { ObstacleTypes } from './ObstacleData';

export class ThemedObstacle extends Tile {
  private obstacleType: string;
  private health: number;
  private maxHealth: number;
  private damageOverlay?: Phaser.GameObjects.Graphics;

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    obstacleType: string,
    row: number,
    col: number
  ) {
    super(scene, x, y, obstacleType, row, col, true);
    
    this.obstacleType = obstacleType;
    const obstacleData = ObstacleTypes[obstacleType as keyof typeof ObstacleTypes];
    this.maxHealth = obstacleData?.health || 1;
    this.health = this.maxHealth;
    
    this.createThemedVisual();
  }

  private createThemedVisual() {
    // Remove default obstacle visual
    this.removeAll(true);

    const obstacleData = ObstacleTypes[this.obstacleType as keyof typeof ObstacleTypes];
    if (!obstacleData) return;

    // Create themed background
    const graphics = this.scene.add.graphics();
    graphics.fillStyle(obstacleData.color, 0.8);
    graphics.fillRoundedRect(-30, -30, 60, 60, 8);
    
    // Add darker border
    graphics.lineStyle(3, 0x000000, 0.6);
    graphics.strokeRoundedRect(-30, -30, 60, 60, 8);
    
    // Add texture pattern based on type
    this.addTexturePattern(graphics, this.obstacleType);
    
    this.add(graphics);

    // Add health indicator if multi-hit obstacle
    if (this.maxHealth > 1) {
      this.createHealthIndicator();
    }

    this.setSize(64, 64);
    this.setInteractive();
  }

  private addTexturePattern(graphics: Phaser.GameObjects.Graphics, type: string) {
    graphics.lineStyle(2, 0xffffff, 0.3);
    
    switch (type) {
      case 'coffin':
        // Add coffin cross pattern
        graphics.strokeRect(-20, -25, 40, 50);
        graphics.moveTo(0, -25);
        graphics.lineTo(0, 25);
        graphics.moveTo(-20, 0);
        graphics.lineTo(20, 0);
        graphics.strokePath();
        break;
        
      case 'garlic':
        // Add garlic segments
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI * 2) / 6;
          const x = Math.cos(angle) * 12;
          const y = Math.sin(angle) * 12;
          graphics.fillStyle(0xffffff, 0.5);
          graphics.fillCircle(x, y, 4);
        }
        break;
        
      case 'tombstone':
        // Add RIP text effect
        graphics.lineStyle(1, 0x000000, 0.8);
        graphics.moveTo(-8, -10);
        graphics.lineTo(8, -10);
        graphics.moveTo(-8, -5);
        graphics.lineTo(8, -5);
        graphics.moveTo(-8, 0);
        graphics.lineTo(8, 0);
        graphics.strokePath();
        break;
        
      case 'chain':
        // Add chain links
        for (let i = -2; i <= 2; i++) {
          graphics.strokeCircle(i * 8, -10, 4);
          graphics.strokeCircle(i * 8, 10, 4);
        }
        break;
        
      case 'web':
        // Add web pattern
        graphics.lineStyle(1, 0xffffff, 0.6);
        for (let i = 0; i < 8; i++) {
          const angle = (i * Math.PI * 2) / 8;
          graphics.moveTo(0, 0);
          graphics.lineTo(Math.cos(angle) * 25, Math.sin(angle) * 25);
        }
        // Add concentric circles
        graphics.strokeCircle(0, 0, 8);
        graphics.strokeCircle(0, 0, 16);
        graphics.strokePath();
        break;
    }
  }

  private createHealthIndicator() {
    const healthBar = this.scene.add.graphics();
    healthBar.x = -25;
    healthBar.y = -35;
    
    // Background
    healthBar.fillStyle(0x000000, 0.7);
    healthBar.fillRect(0, 0, 50, 6);
    
    // Health bar
    const healthPercent = this.health / this.maxHealth;
    const color = healthPercent > 0.6 ? 0x00ff00 : healthPercent > 0.3 ? 0xffff00 : 0xff0000;
    healthBar.fillStyle(color, 1);
    healthBar.fillRect(1, 1, (50 - 2) * healthPercent, 4);
    
    this.add(healthBar);
  }

  public takeDamage(): boolean {
    this.health--;
    
    // Create damage effect
    this.createDamageEffect();
    
    // Update health indicator
    this.removeAll(true);
    this.createThemedVisual();
    
    return this.health <= 0;
  }

  private createDamageEffect() {
    // Flash red
    this.scene.tweens.add({
      targets: this,
      alpha: 0.3,
      duration: 100,
      yoyo: true,
      repeat: 1
    });
    
    // Shake effect
    const originalX = this.x;
    this.scene.tweens.add({
      targets: this,
      x: originalX + 3,
      duration: 50,
      yoyo: true,
      repeat: 3,
      onComplete: () => {
        this.x = originalX;
      }
    });
  }

  public getObstacleType(): string {
    return this.obstacleType;
  }

  public getHealth(): number {
    return this.health;
  }

  public getMaxHealth(): number {
    return this.maxHealth;
  }
}