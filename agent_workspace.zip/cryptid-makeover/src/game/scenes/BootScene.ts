import Phaser from 'phaser';

export class BootScene extends Phaser.Scene {
  constructor() {
    super({ key: 'BootScene' });
  }

  preload() {
    // Create loading bar
    const loadingBar = this.add.graphics();
    const loadingBox = this.add.graphics();
    
    loadingBox.fillStyle(0x4f518c, 0.8);
    loadingBox.fillRect(240, 270, 320, 50);
    
    const width = this.cameras.main.width;
    const height = this.cameras.main.height;
    
    const loadingText = this.make.text({
      x: width / 2,
      y: height / 2 - 50,
      text: 'Loading...',
      style: {
        font: '20px Arial',
        color: '#ffffff'
      }
    });
    loadingText.setOrigin(0.5, 0.5);
    
    const percentText = this.make.text({
      x: width / 2,
      y: height / 2 - 5,
      text: '0%',
      style: {
        font: '18px Arial',
        color: '#ffffff'
      }
    });
    percentText.setOrigin(0.5, 0.5);
    
    const assetText = this.make.text({
      x: width / 2,
      y: height / 2 + 50,
      text: '',
      style: {
        font: '16px Arial',
        color: '#ffffff'
      }
    });
    assetText.setOrigin(0.5, 0.5);
    
    this.load.on('progress', (value: number) => {
      percentText.setText(Math.floor(value * 100) + '%');
      loadingBar.clear();
      loadingBar.fillStyle(0xff47da, 1);
      loadingBar.fillRect(250, 280, 300 * value, 30);
    });
    
    this.load.on('fileprogress', (file: any) => {
      assetText.setText('Loading asset: ' + file.key);
    });
    
    this.load.on('complete', () => {
      loadingBar.destroy();
      loadingBox.destroy();
      loadingText.destroy();
      percentText.destroy();
      assetText.destroy();
    });
    
    // Load game assets
    this.loadGameAssets();
  }

  private loadGameAssets() {
    // Create colored rectangles for tiles since we don't have individual tile sprites
    this.createTileTextures();
    
    // Load background images
    this.load.image('vampire-bg', '/images/vampire-castle.jpg');
    this.load.image('werewolf-bg', '/images/werewolf-forest.jpg');
    this.load.image('zombie-bg', '/images/zombie-graveyard.jpg');
    this.load.image('washington-bg', '/images/washington-dc.jpg');
    this.load.image('morganna', '/images/morganna-witch.jpeg');
    
    // Create power-up textures
    this.createPowerUpTextures();
    
    // Create particle textures
    this.createParticleTextures();
  }

  private createTileTextures() {
    const tileSize = 64;
    
    // Vampire tiles
    this.createTileTexture('fang', 0xe63946, '🧛‍♂️'); // Red with vampire emoji
    this.createTileTexture('bat', 0x2c2a4a, '🦇'); // Dark purple with bat
    this.createTileTexture('blood', 0x8b0000, '🩸'); // Dark red with blood
    this.createTileTexture('coffin', 0x654321, '⚰️'); // Brown with coffin
    this.createTileTexture('garlic', 0xfffaf0, '🧄'); // Off-white with garlic
    this.createTileTexture('mirror', 0xc0c0c0, '🪞'); // Silver with mirror
    this.createTileTexture('stake', 0x8b4513, '🔨'); // Brown with stake
    
    // Werewolf tiles
    this.createTileTexture('moon', 0xf5f5dc, '🌕'); // Beige with moon
    this.createTileTexture('paw', 0x8b4513, '🐾'); // Brown with paw
    this.createTileTexture('howl', 0x4682b4, '🌙'); // Steel blue with howl
    this.createTileTexture('trap', 0x696969, '🪤'); // Gray with trap
    this.createTileTexture('chain', 0x708090, '⛓️'); // Slate gray with chain
    this.createTileTexture('wolfsbane', 0x9370db, '🌿'); // Purple with plant
    
    // Zombie tiles
    this.createTileTexture('brain', 0xff69b4, '🧠'); // Pink with brain
    this.createTileTexture('bone', 0xf5f5dc, '🦴'); // Beige with bone
    this.createTileTexture('potion', 0x00ff00, '🧪'); // Green with potion
    this.createTileTexture('tombstone', 0x708090, '🪦'); // Gray with tombstone
    this.createTileTexture('plague', 0x32cd32, '☠️'); // Lime with skull
    this.createTileTexture('decay', 0x556b2f, '🤢'); // Dark olive with decay
    this.createTileTexture('antidote', 0x00ffff, '💊'); // Cyan with antidote
  }

  private createTileTexture(key: string, color: number, emoji: string) {
    const tileSize = 64;
    const graphics = this.add.graphics();
    
    // Create rounded rectangle background
    graphics.fillStyle(color, 1);
    graphics.fillRoundedRect(0, 0, tileSize, tileSize, 8);
    
    // Add border
    graphics.lineStyle(3, 0xffffff, 0.8);
    graphics.strokeRoundedRect(0, 0, tileSize, tileSize, 8);
    
    // Add inner glow effect
    graphics.fillStyle(0xffffff, 0.3);
    graphics.fillRoundedRect(4, 4, tileSize - 8, tileSize - 8, 6);
    
    // Generate texture
    graphics.generateTexture(key, tileSize, tileSize);
    graphics.destroy();
    
    // Add emoji overlay (this would be handled differently in a real implementation)
    const emojiGraphics = this.add.graphics();
    emojiGraphics.fillStyle(0x000000, 0.1);
    emojiGraphics.fillCircle(tileSize/2, tileSize/2, tileSize/3);
    emojiGraphics.generateTexture(key + '_overlay', tileSize, tileSize);
    emojiGraphics.destroy();
  }

  private createPowerUpTextures() {
    // Horizontal Rocket (row clear)
    this.createPowerUpTexture('rocket-h', 0xff6b35, '🚀');
    
    // Vertical Rocket (column clear)
    this.createPowerUpTexture('rocket-v', 0xff6b35, '🚀');
    
    // Bomb (3x3 explosion)
    this.createPowerUpTexture('bomb', 0xff0000, '💣');
    
    // Rainbow piece (color clear)
    this.createPowerUpTexture('rainbow', 0x9932cc, '🌈');
  }

  private createPowerUpTexture(key: string, color: number, emoji: string) {
    const tileSize = 64;
    const graphics = this.add.graphics();
    
    // Create glowing effect
    graphics.fillStyle(color, 1);
    graphics.fillCircle(tileSize/2, tileSize/2, tileSize/2 - 2);
    
    // Add bright border
    graphics.lineStyle(4, 0xffffff, 1);
    graphics.strokeCircle(tileSize/2, tileSize/2, tileSize/2 - 2);
    
    // Add inner shine
    graphics.fillStyle(0xffffff, 0.6);
    graphics.fillCircle(tileSize/2 - 8, tileSize/2 - 8, 8);
    
    graphics.generateTexture(key, tileSize, tileSize);
    graphics.destroy();
  }

  private createParticleTextures() {
    // Star particle
    const starGraphics = this.add.graphics();
    starGraphics.fillStyle(0xffd700, 1);
    // Create a simple star shape
    starGraphics.beginPath();
    starGraphics.moveTo(8, 2);
    starGraphics.lineTo(10, 6);
    starGraphics.lineTo(14, 6);
    starGraphics.lineTo(11, 9);
    starGraphics.lineTo(12, 14);
    starGraphics.lineTo(8, 11);
    starGraphics.lineTo(4, 14);
    starGraphics.lineTo(5, 9);
    starGraphics.lineTo(2, 6);
    starGraphics.lineTo(6, 6);
    starGraphics.closePath();
    starGraphics.fillPath();
    starGraphics.generateTexture('star', 16, 16);
    starGraphics.destroy();
    
    // Sparkle particle
    const sparkleGraphics = this.add.graphics();
    sparkleGraphics.fillStyle(0xffffff, 1);
    sparkleGraphics.fillCircle(4, 4, 4);
    sparkleGraphics.generateTexture('sparkle', 8, 8);
    sparkleGraphics.destroy();
  }

  create() {
    // Game is loaded, can start the UI
    this.scene.start('UIScene');
  }
}