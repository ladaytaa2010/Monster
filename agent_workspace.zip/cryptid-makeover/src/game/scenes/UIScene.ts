import Phaser from 'phaser';

export class UIScene extends Phaser.Scene {
  constructor() {
    super({ key: 'UIScene' });
  }

  create() {
    // This scene handles the main menu and UI overlays
    // The actual React UI will overlay this scene
    
    // Create a transparent background
    const bg = this.add.rectangle(
      this.cameras.main.centerX,
      this.cameras.main.centerY,
      this.cameras.main.width,
      this.cameras.main.height,
      0x000000,
      0
    );
    
    // This scene mainly serves as a container for Phaser to render to
    // All UI interactions will be handled by React components
  }

  public showGameUI() {
    // Method to switch to game UI mode
    this.cameras.main.setBackgroundColor(0x2c2a4a);
  }

  public showMenuUI() {
    // Method to switch to menu UI mode
    this.cameras.main.setBackgroundColor(0x000000);
  }
}