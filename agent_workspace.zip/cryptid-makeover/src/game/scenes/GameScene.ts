import Phaser from 'phaser';
import { Board } from '../objects/Board';
import { Level } from '../../stores/gameStore';

export class GameScene extends Phaser.Scene {
  private board?: Board;
  private level?: Level;
  private movesLeft: number = 0;
  private score: number = 0;
  private targetProgress: { [key: string]: number } = {};
  private callbacks: any;

  constructor() {
    super({ key: 'GameScene' });
  }

  create() {
    // Get level data and callbacks from registry
    this.level = this.registry.get('currentLevel');
    this.callbacks = this.registry.get('callbacks');
    
    if (!this.level) {
      console.error('No level data provided');
      return;
    }

    this.movesLeft = this.level.moves;
    this.score = 0;
    this.targetProgress = {};
    
    // Initialize target progress
    Object.keys(this.level.targetTiles).forEach(tileType => {
      this.targetProgress[tileType] = 0;
    });

    // Create background
    this.createBackground();
    
    // Create the game board
    this.createBoard();
    
    // Set up UI updates
    this.setupUIUpdates();
  }

  private createBackground() {
    // Add a subtle background
    const bg = this.add.rectangle(
      this.cameras.main.centerX,
      this.cameras.main.centerY,
      this.cameras.main.width,
      this.cameras.main.height,
      0x2c2a4a,
      0.3
    );
  }

  private createBoard() {
    if (!this.level) return;
    
    const boardX = this.cameras.main.centerX;
    const boardY = this.cameras.main.centerY + 20; // Offset for UI
    
    this.board = new Board(this, boardX, boardY, this.level);
    
    // Listen for board events
    this.board.on('tilesMatched', this.onTilesMatched, this);
    this.board.on('noMoreMoves', this.onNoMoreMoves, this);
    this.board.on('moveUsed', this.onMoveUsed, this);
  }

  private setupUIUpdates() {
    // Send initial UI state
    this.updateUI();
  }

  private onTilesMatched(matchData: { type: string; count: number; score: number }) {
    // Update score
    this.score += matchData.score;
    
    // Update target progress - check all possible target names
    const targetKeys = Object.keys(this.level?.targetTiles || {});
    targetKeys.forEach(targetKey => {
      // Match both the exact type and the base tile types
      if (targetKey === matchData.type || 
          this.isMatchingTileType(targetKey, matchData.type)) {
        this.targetProgress[targetKey] = (this.targetProgress[targetKey] || 0) + matchData.count;
      }
    });
    
    // Notify UI of coins earned
    if (this.callbacks?.onCoinsEarned) {
      this.callbacks.onCoinsEarned(Math.floor(matchData.score / 10));
    }
    
    // Update UI
    this.updateUI();
    
    // Check win condition after a small delay to allow for cascading matches
    this.time.delayedCall(100, () => {
      this.checkWinCondition();
    });
  }
  
  private isMatchingTileType(targetType: string, matchedType: string): boolean {
    // Map different tile types that should count toward the same objective
    const tileTypeMap: { [key: string]: string[] } = {
      'fang': ['fang'],
      'bat': ['bat'],
      'blood': ['blood'],
      'coffin': ['coffin'],
      'garlic': ['garlic'],
      'mirror': ['mirror'],
      'stake': ['stake'],
      // Werewolf tiles
      'moon': ['moon'],
      'paw': ['paw'],
      'howl': ['howl'],
      'trap': ['trap'],
      'chain': ['chain'],
      'wolfsbane': ['wolfsbane'],
      // Zombie tiles
      'brain': ['brain'],
      'bone': ['bone'],
      'potion': ['potion'],
      'tombstone': ['tombstone'],
      'plague': ['plague'],
      'decay': ['decay'],
      'antidote': ['antidote']
    };
    
    return tileTypeMap[targetType]?.includes(matchedType) || targetType === matchedType;
  }

  private onMoveUsed() {
    this.movesLeft--;
    
    if (this.callbacks?.onMoveUsed) {
      this.callbacks.onMoveUsed();
    }
    
    this.updateUI();
    
    // Check lose condition
    if (this.movesLeft <= 0) {
      this.checkWinCondition();
    }
  }

  private onNoMoreMoves() {
    // End game - no more moves possible
    this.endGame(false);
  }

  private updateUI() {
    if (this.callbacks?.onGameStateChange) {
      this.callbacks.onGameStateChange({
        movesLeft: this.movesLeft,
        score: this.score,
        targetProgress: { ...this.targetProgress },
        level: this.level
      });
    }
  }

  private checkWinCondition() {
    if (!this.level) return;
    
    // Check if all targets are met
    const allTargetsMet = Object.keys(this.level.targetTiles).every(tileType => {
      const required = this.level!.targetTiles[tileType];
      const collected = this.targetProgress[tileType] || 0;
      return collected >= required;
    });
    
    if (allTargetsMet) {
      // Calculate stars based on moves left
      let stars = 1;
      const movesUsed = this.level.moves - this.movesLeft;
      const efficiency = movesUsed / this.level.moves;
      
      if (efficiency <= 0.6) stars = 3; // Used 60% or less moves
      else if (efficiency <= 0.8) stars = 2; // Used 80% or less moves
      
      this.endGame(true, stars);
    } else if (this.movesLeft <= 0) {
      this.endGame(false);
    }
  }

  private endGame(success: boolean, stars: number = 0) {
    // Disable board interaction
    if (this.board) {
      this.board.setInteractionEnabled(false);
    }
    
    // Delay to show final animation
    this.time.delayedCall(1000, () => {
      if (this.callbacks?.onLevelComplete) {
        this.callbacks.onLevelComplete(success, stars);
      }
      
      // Return to UI scene
      this.scene.stop('GameScene');
      this.scene.wake('UIScene');
    });
  }

  public pauseGame() {
    this.scene.pause();
  }

  public resumeGame() {
    this.scene.resume();
  }
}