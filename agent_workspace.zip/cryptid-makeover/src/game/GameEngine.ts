import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene';
import { GameScene } from './scenes/GameScene';
import { UIScene } from './scenes/UIScene';

export class GameEngine {
  private game: Phaser.Game | null = null;
  private gameCallbacks: {
    onLevelComplete?: (success: boolean, stars: number) => void;
    onCoinsEarned?: (amount: number) => void;
    onMoveUsed?: () => void;
    onGameStateChange?: (state: any) => void;
  } = {};

  constructor() {
    this.initializePhaser();
  }

  private initializePhaser() {
    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      width: 800,
      height: 600,
      parent: 'game-canvas',
      backgroundColor: '#2c2a4a',
      scene: [BootScene, GameScene, UIScene],
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { x: 0, y: 0 },
          debug: false
        }
      },
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        min: {
          width: 320,
          height: 240
        },
        max: {
          width: 1200,
          height: 900
        }
      }
    };

    this.game = new Phaser.Game(config);
  }

  public setCallbacks(callbacks: typeof this.gameCallbacks) {
    this.gameCallbacks = callbacks;
    
    // Pass callbacks to scenes through registry
    this.game?.registry.set('callbacks', callbacks);
  }

  public startLevel(levelData: any) {
    if (this.game) {
      console.log('Starting level:', levelData);
      this.game.registry.set('currentLevel', levelData);
      
      // Stop any running scenes first
      if (this.game.scene.isActive('GameScene')) {
        this.game.scene.stop('GameScene');
      }
      if (this.game.scene.isActive('UIScene')) {
        this.game.scene.stop('UIScene');
      }
      
      // Start the GameScene
      this.game.scene.start('GameScene');
    }
  }

  public pauseGame() {
    if (this.game) {
      this.game.scene.pause('GameScene');
    }
  }

  public resumeGame() {
    if (this.game) {
      this.game.scene.resume('GameScene');
    }
  }

  public destroy() {
    if (this.game) {
      this.game.destroy(true);
      this.game = null;
    }
  }

  public getGame(): Phaser.Game | null {
    return this.game;
  }
}

// Singleton instance
export const gameEngine = new GameEngine();