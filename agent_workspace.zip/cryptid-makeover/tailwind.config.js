/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'display': ['Luckiest Guy', 'cursive'],
        'body': ['Nunito Sans', 'sans-serif'],
      },
      colors: {
        'midnight-purple': '#2c2a4a',
        'off-white': '#f5f5f5',
        'shadowed-blue': '#4f518c',
        'arcane-pink': '#ff47da',
        'electric-teal': '#00f5d4',
        'glimmering-gold': '#ffd700',
        'pure-white': '#ffffff',
        'charcoal': '#333333',
        'cursed-red': '#e63946',
      },
      backgroundImage: {
        'gradient-magic': 'linear-gradient(135deg, #ff47da, #00f5d4)',
        'gradient-dark': 'linear-gradient(135deg, #2c2a4a, #4f518c)',
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'sparkle': 'sparkle 1.5s ease-in-out infinite',
        'tile-match': 'tile-match 0.3s ease-out',
        'tile-drop': 'tile-drop 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(255, 71, 218, 0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(255, 71, 218, 0.6)' },
        },
        sparkle: {
          '0%, 100%': { transform: 'scale(1) rotate(0deg)', opacity: '1' },
          '50%': { transform: 'scale(1.2) rotate(180deg)', opacity: '0.8' },
        },
        'tile-match': {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.2)' },
          '100%': { transform: 'scale(0)' },
        },
        'tile-drop': {
          '0%': { transform: 'translateY(-100px) scale(0.8)', opacity: '0' },
          '100%': { transform: 'translateY(0) scale(1)', opacity: '1' },
        },
      },
      boxShadow: {
        'glow': '0 0 20px rgba(255, 71, 218, 0.3)',
        'glow-lg': '0 0 40px rgba(255, 71, 218, 0.4)',
        'inner-glow': 'inset 0 0 20px rgba(255, 71, 218, 0.2)',
      },
      backdropBlur: {
        'xs': '2px',
      },
    },
  },
  plugins: [],
}