# Project Makeover: Game Mechanics and Design Analysis

This report details the core gameplay mechanics, design elements, and progression systems of the mobile game Project Makeover. The information is intended to serve as a guide for creating a similar match-3 game with a new theme.

## 1. Core Match-3 Mechanics

The core gameplay of Project Makeover revolves around a standard match-3 puzzle grid. The fundamental rules are as follows:

*   **Matching:** Players must swap adjacent tiles to create a line of three or more identical tiles. Matched tiles are removed from the board.
*   **Cascading Tiles:** When tiles are removed, tiles from above fall to fill the empty spaces, potentially creating new matches in a chain reaction.
*   **Objectives:** Each level has a specific objective that must be completed within a limited number of moves. Common objectives include:
    *   Collecting a certain number of a specific tile type.
    *   Clearing obstacles from the board.
*   **Lives System:** Players are given a set number of lives. Failing to complete a level's objective within the move limit results in the loss of a life. Lives regenerate over time or can be purchased.

## 2. Power-ups and Special Tiles

Power-ups, or "boosters," are special tiles created by matching more than three standard tiles. They are crucial for clearing large sections of the board and overcoming difficult obstacles.

### In-Game Power-ups

These power-ups are created during gameplay through specific tile combinations:

*   **Rockets:**
    *   **Creation:** Match four tiles in a line.
    *   **Effect:** Clears an entire row or column, depending on the rocket's orientation.
*   **Firecrackers:**
    *   **Creation:** Match four tiles in a 2x2 square.
    *   **Effect:** Clears surrounding tiles in a small cross-shaped explosion.
*   **Bombs:**
    *   **Creation:** Match five tiles in an L or T shape.
    *   **Effect:** Clears a 3x3 area of tiles.
*   **Rainbow Piece:**
    *   **Creation:** Match five tiles in a straight line.
    -   **Effect:** Clears all tiles of a single color from the board. The color is determined by the tile it is swapped with.

### Power-up Combinations

Combining two power-ups results in an enhanced effect:

*   **Rocket + Rocket:** Clears both a row and a column.
*   **Bomb + Bomb:** Creates a larger 5x5 explosion.
*   **Rocket + Bomb:** Clears three rows and three columns.
*   **Rainbow Piece + Any Power-up:** All tiles of the swapped color turn into the corresponding power-up and are activated.

### Pre-Game Boosters and Tools

Players can also use special tools and boosters before and during a level:

*   **Scissors:** Removes a single tile.
*   **Brush:** Clears a row and column.
*   **Perfume Bottle:** Creates a large explosion.



## 3. Level Design and Obstacles

Level design in Project Makeover is structured around a chapter-based progression system, rather than a linear map. The core of the level design is the match-3 puzzle, which serves as the primary mechanic for earning the soft currency needed for the makeover meta-game.

While specific level layouts are randomized, they are designed with increasing difficulty. This is achieved through:

*   **More Complex Objectives:** Early levels may only require collecting a certain number of basic tiles. Later levels introduce more complex objectives, such as clearing specific types of obstacles.
*   **Restrictive Turn Limits:** As the difficulty increases, the number of moves allowed to complete the objective becomes more restrictive.
*   **Introduction of New Obstacles:** The game progressively introduces new and more challenging obstacles that require specific strategies to overcome. 

### Obstacles

Obstacles are special tiles or elements on the board that impede progress and must be cleared to complete objectives. Common obstacles include:

*   **Shirts and Lipsticks:** Stationary items that are cleared by matching adjacent tiles.
*   **Combs:** Similar to shirts, but can be moved around the board.
*   **Cameras:** Cannot be moved or cleared directly. They are collected by clearing the tiles beneath them, allowing them to drop off the board.
*   **Belts:** These wrap around tiles and must be cleared by matching adjacent tiles.
*   **Spray Bottles:** These are cleared by creating matches next to them, which builds up pressure until they are automatically collected.

## 4. Visual Style and UI/UX

Project Makeover features a bright, colorful, and cartoonish art style. The game draws inspiration from fashion and makeover-themed TV shows, creating a familiar and appealing aesthetic.

### Visual Elements

*   **2D and 3D Combination:** The game uses a mix of 2D and 3D elements. The makeover clients are rendered in 3D, while most of the UI and game board elements are 2D.
*   **"Before and After" Emphasis:** A key visual element is the dramatic transformation of the clients and their spaces. The "before" state is often messy and unattractive to make the "after" state more impactful.
*   **Match-3 Board:** The puzzle board itself is a classic grid with colorful, easily distinguishable tiles. The game features satisfying special effects and explosions when tiles are cleared.

### UI/UX

The user interface is designed to be intuitive and easy to navigate, despite the number of features. The main screen is organized as follows:

*   **Top Bar:** Displays the player's lives, gems (hard currency), and coins (soft currency).
*   **Left Side:** Shows the player's avatar and current makeover tasks.
*   **Bottom Right:** The prominent "Play" button, which takes the player to the match-3 board.
*   **Tutorial:** The game features a comprehensive tutorial that guides new players through the various features. Instructions are provided for every new element introduced, ensuring a smooth learning curve.


## 5. Progression and Economy

Project Makeover's progression is tied to a chapter-based system, with each chapter focusing on a new client to be made over. The core loop involves playing match-3 levels to earn coins, which are then used to complete makeover tasks.

### Level Progression

*   **Continuous Updates:** The game is regularly updated with new levels and clients. As of recent updates, the game has over 4800 levels.
*   **Standard Levels:** Each standard level rewards the player with 300 coins upon completion.
*   **One-Time Levels:** These are special, more difficult levels that can only be attempted once. They offer significantly higher rewards than standard levels.

### Coin Economy

*   **Coins (Soft Currency):** This is the primary currency earned by playing match-3 levels. Coins are used to purchase new clothes, hairstyles, makeup, and furniture for the clients, thus advancing the story.
*   **Gems (Hard Currency):** This is the premium currency, which can be purchased with real money. Gems are used to buy special boosters, extra lives, and additional moves at the end of a failed level.


## 6. Monetization and Social Features

Project Makeover employs a variety of monetization strategies and social features to engage players and generate revenue.

### Monetization

*   **In-App Purchases (IAPs):** The primary monetization method is the sale of gems (hard currency) for real money. Gems can be used to:
    *   Purchase extra moves to complete a level.
    *   Refill lives.
    *   Buy special pre-game boosters and in-game tools.
*   **Sales and Special Offers:** The game frequently presents players with limited-time offers and sales on gem packs and bundles.

### Social Features

*   **Teams:** Players can join or create teams, which allows them to:
    *   Request and donate lives to teammates.
    *   Chat with other team members.
*   **Leaderboards:** The game features leaderboards that rank players based on their level progression, fostering a sense of competition.
*   **Social Media Integration:** Players can connect their game to Facebook to save their progress and play with friends.

## 7. Tutorial and Onboarding

The onboarding process in Project Makeover is designed to be seamless and intuitive. The game guides new players through the core mechanics and features with a hands-on tutorial.

*   **Guided Introduction:** New players are introduced to the game's narrative and core mechanics by the in-game characters.
*   **Interactive Learning:** The tutorial is interactive, prompting players to perform actions such as making their first match, using a power-up, and completing a makeover task.
*   **Progressive Disclosure:** The game does not overwhelm players with all of its features at once. New mechanics and features are introduced gradually as the player progresses through the early levels.
