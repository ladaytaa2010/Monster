# Source Log

This file tracks all sources used for the research on Project Makeover.



1. [Project Makeover Wiki - Fandom](https://projectmakeover.fandom.com/wiki/Project_Makeover_Wiki)
2. [Beginner's Guide for Project Makeover with the Best Tips ...](https://www.bluestacks.com/blog/game-guides/project-makeover/pmo-beginner-guide-en.html)
3. [Project Makeover Gameplay Walkthrough Part 1 (Android iOS)](https://www.youtube.com/watch?v=FCYLTBNUIOg)
4. [Project Makeover: An In-Depth Look at Game Mechanics ...](https://medium.com/@starwardgames/project-makeover-an-in-depth-look-at-game-mechanics-and-community-features-5ee6338b63f8)

5. [Project Makeover Monetization: Bringing Match-3 Back to Life](https://medium.com/udonis/project-makeover-monetization-bringing-match-3-back-to-life-c567a3e96cf4)
6. [How to crack the Match 3 code: Lessons from Project ...](https://medium.com/ironsource-levelup/how-to-crack-the-match-3-code-lessons-from-project-makeover-c1c830404de6)